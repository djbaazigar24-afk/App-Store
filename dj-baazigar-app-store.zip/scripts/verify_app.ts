import { chromium } from 'playwright';
import fs from 'node:fs';

async function verify() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  const consoleLogs: string[] = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleLogs.push(`[CONSOLE ERROR] ${msg.text()}`);
    }
  });

  if (!fs.existsSync('.playwright-cli')) {
    fs.mkdirSync('.playwright-cli', { recursive: true });
  }

  console.log('1. Navigating to http://localhost:3000...');
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });

  console.log('2. Taking desktop screenshot...');
  await page.screenshot({ path: '.playwright-cli/r1-desktop.png', fullPage: false });

  // Journey 1: Verify Header and App Cards
  const title = await page.title();
  console.log('Page Title:', title);

  // Check secret ADMIN detection
  console.log('3. Testing Secret ADMIN keyword in search...');
  const searchInput = page.locator('input[aria-label="Search applications"]');
  await searchInput.fill('ADMIN');
  await page.waitForTimeout(500);

  const adminEntryBtn = page.locator('button:has-text("Admin Entry")');
  const isVisible = await adminEntryBtn.isVisible();
  console.log('Admin Entry button visible upon typing ADMIN:', isVisible);

  await page.screenshot({ path: '.playwright-cli/r1-admin-search.png' });

  // Click Admin Entry and check password modal
  console.log('4. Clicking Admin Entry button...');
  await adminEntryBtn.click();
  await page.waitForTimeout(600);

  const modalTitle = await page.locator('text=ADMIN TERMINAL ACCESS').isVisible();
  console.log('Admin Password Modal visible:', modalTitle);

  // Test admin login with password "ADMIN"
  console.log('5. Entering admin password "ADMIN" and submitting...');
  await page.locator('input[placeholder="Enter admin password..."]').fill('ADMIN');
  await page.locator('button:has-text("Authenticate & Enter Dashboard")').click();
  await page.waitForTimeout(1000);

  const adminHeading = await page.locator('text=Dashboard Analytics').isVisible();
  console.log('Super Admin Dashboard visible after login:', adminHeading);

  await page.screenshot({ path: '.playwright-cli/r1-admin-dashboard.png' });

  // Exit back to store
  console.log('6. Exiting admin to store...');
  await page.locator('button:has-text("Exit to Store")').click();
  await page.waitForTimeout(500);

  // Clear search
  await searchInput.fill('');
  await page.waitForTimeout(500);

  // Journey 2: Test opening an app and checking the payment modal
  console.log('7. Testing App Card click & FamGateway Payment Modal...');
  const buyButton = page.locator('button:has-text("Buy ₹")').first();
  await buyButton.click();
  await page.waitForTimeout(1200);

  const paymentHeader = await page.locator('text=FamGateway UPI Instant Payment').isVisible();
  console.log('FamGateway Payment Modal visible:', paymentHeader);

  await page.screenshot({ path: '.playwright-cli/r1-payment-modal.png' });

  // Test Simulate Successful Payment
  console.log('8. Testing Simulate Successful UPI Payment in modal...');
  const simulateBtn = page.locator('button:has-text("Simulate Successful UPI Payment")');
  if (await simulateBtn.isVisible()) {
    await simulateBtn.click();
    await page.waitForTimeout(1000);
    const successMsg = await page.locator('text=APK Download Unlocked!').isVisible();
    console.log('Payment success state reached and download button unlocked:', successMsg);
    await page.screenshot({ path: '.playwright-cli/r1-payment-success.png' });
  }

  // Mobile viewport check (390x844)
  console.log('9. Checking Mobile Android Viewport (390x844)...');
  const mobileContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const mobilePage = await mobileContext.newPage();
  await mobilePage.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await mobilePage.screenshot({ path: '.playwright-cli/r1-mobile.png' });

  console.log('Console errors encountered:', consoleLogs.length);
  if (consoleLogs.length > 0) {
    console.log(consoleLogs);
  }

  await browser.close();
  console.log('Verification completed successfully!');
}

verify().catch((err) => {
  console.error('Verification script error:', err);
  process.exit(1);
});
