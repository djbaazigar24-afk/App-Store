import { Router, Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { db } from '../db';
import { verifyDownloadToken } from '../logic/downloadAuth';
import { buildAndroidApkArchive } from '../logic/apkBuilder';

export const downloadRouter = Router();

const DOWNLOAD_SECRET = process.env.ADMIN_SESSION_SECRET || 'djbaazigar_secret_token_key_2026';

/**
 * GET /api/download/verify-token?token=...&app_id=...
 */
downloadRouter.get('/verify-token', (req: Request, res: Response): void => {
  const token = req.query.token as string;
  const appId = req.query.app_id as string;

  if (!token || !appId) {
    res.status(400).json({ valid: false, error: 'Token and appId required' });
    return;
  }

  const result = verifyDownloadToken(token, DOWNLOAD_SECRET);
  if (!result.valid || result.payload?.appId !== appId) {
    res.status(403).json({ valid: false, error: result.error || 'Token invalid for this app' });
    return;
  }

  res.json({ valid: true, expiresAt: result.payload.expiresAt });
});

/**
 * GET /api/download/apk/:appId
 * Securely streams or delivers the APK file
 */
downloadRouter.get('/apk/:appId', (req: Request, res: Response): void => {
  const appId = req.params.appId;
  const token = (req.query.token as string) || (req.headers['x-download-token'] as string);

  const app = db.getAppById(appId);
  if (!app) {
    res.status(404).send('Application not found');
    return;
  }

  if (!app.downloadsEnabled) {
    res.status(403).send('Downloads for this application are currently disabled by administrator.');
    return;
  }

  // Check if free or requires verified token
  const settings = db.getSettings();
  if (app.price > 0) {
    if (!token) {
      res.status(401).send('Unauthorized. Verified payment token required to download this VIP app.');
      return;
    }

    const verification = verifyDownloadToken(token, DOWNLOAD_SECRET);
    if (!verification.valid || verification.payload?.appId !== appId) {
      res.status(403).send('Forbidden. Invalid or expired download token.');
      return;
    }
  } else {
    if (!settings.allowDirectFreeDownloads) {
      res.status(403).send('Free downloads are temporarily restricted.');
      return;
    }
  }

  // Increment download counter
  db.incrementDownload(app.id);

  // Clean filename for Android Chrome
  const safeTitle = app.name.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeTitle}_v${app.version}_DJBaazigar.apk`;

  // 1. If physical APK was uploaded by admin to data/uploads
  if (app.apkFileName) {
    const uploadedPath = path.join(process.cwd(), 'data', 'uploads', app.apkFileName);
    if (fs.existsSync(uploadedPath)) {
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.sendFile(uploadedPath);
      return;
    }
  }

  // 2. If external direct download URL was configured
  if (app.apkDownloadUrl && app.apkDownloadUrl.startsWith('http')) {
    res.redirect(app.apkDownloadUrl);
    return;
  }

  // 3. Fallback: Certified Android APK archive
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');

  const apkArchive = buildAndroidApkArchive(
    app.packageName || 'com.djbaazigar.app',
    app.version || '1.0.0',
    app.name
  );

  res.send(apkArchive);
});
