import { Router, Request, Response } from 'express';
import crypto from 'node:crypto';
import QRCode from 'qrcode';
import { db } from '../db';
import { PaymentTransaction } from '../types';
import { isDuplicateUtr, validatePaymentAmount, generateUpiIntentUrl } from '../logic/paymentRules';
import { createDownloadToken } from '../logic/downloadAuth';

export const paymentRouter = Router();

const FAMGATEWAY_BASE = process.env.FAMGATEWAY_BASE_URL || 'https://famgateway.in';
const FAMGATEWAY_KEY = process.env.FAMGATEWAY_API_KEY || '';
const FAMGATEWAY_UPI = process.env.FAMGATEWAY_UPI_ID || 'abhijit-dalui@fam';
const DOWNLOAD_SECRET = process.env.ADMIN_SESSION_SECRET || 'djbaazigar_secret_token_key_2026';

const isLiveKeyConfigured = () => {
  return (
    FAMGATEWAY_KEY &&
    FAMGATEWAY_KEY.trim() !== '' &&
    FAMGATEWAY_KEY !== 'YOUR_FAMGATEWAY_API_KEY' &&
    FAMGATEWAY_KEY !== 'MY_FAMGATEWAY_KEY'
  );
};

/**
 * POST /api/payment/create-order
 * Creates a unique FamGateway payment order for an application purchase.
 */
paymentRouter.post('/create-order', async (req: Request, res: Response): Promise<void> => {
  try {
    const { appId, customerName, customerPhone, customerEmail } = req.body;

    if (!appId) {
      res.status(400).json({ error: 'appId is required' });
      return;
    }

    const app = db.getAppById(appId);
    if (!app) {
      res.status(404).json({ error: 'Application not found' });
      return;
    }

    if (app.price <= 0) {
      res.status(400).json({ error: 'This application is free. No payment required.' });
      return;
    }

    const requestedAmount = app.price;
    const internalId = `ORD_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    let orderId = `fg_${Date.now().toString(36)}${Math.random().toString(36).substring(2, 6)}`;
    let payableAmount = requestedAmount;
    let upiId = FAMGATEWAY_UPI;
    let qrUrl = `${FAMGATEWAY_BASE}/api/qr-image.php?order_id=${orderId}`;
    let checkoutUrl = `${FAMGATEWAY_BASE}/pay.php?order_id=${orderId}`;
    let upiIntent = generateUpiIntentUrl({
      upiId,
      payeeName: 'DJ Baazigar',
      amount: payableAmount,
      transactionNote: `${app.name.substring(0, 20)} VIP`,
      orderId,
    });

    // If live API key is configured, call FamGateway API
    if (isLiveKeyConfigured()) {
      try {
        const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
        const gatewayRes = await fetch(`${FAMGATEWAY_BASE}/api/create-order`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Api-Key': FAMGATEWAY_KEY,
          },
          body: JSON.stringify({
            amount: requestedAmount,
            customer_name: customerName || 'DJ Baazigar Customer',
            customer_phone: customerPhone || '9876543210',
            customer_email: customerEmail || 'customer@example.com',
            redirect_url: `${appUrl}/payment-success?order_id=${internalId}`,
            webhook_url: `${appUrl}/api/famgateway-webhook`,
          }),
        });

        const gatewayData = (await gatewayRes.json()) as any;
        if (gatewayData.status === 'success' && gatewayData.data) {
          orderId = gatewayData.data.order_id || orderId;
          payableAmount = parseFloat(gatewayData.data.payable_amount || gatewayData.data.amount || requestedAmount);
          upiId = gatewayData.data.upi_id || upiId;
          qrUrl = gatewayData.data.qr_url || `${FAMGATEWAY_BASE}/api/qr-image.php?order_id=${orderId}`;
          checkoutUrl = gatewayData.data.checkout_url || `${FAMGATEWAY_BASE}/pay.php?order_id=${orderId}`;
          upiIntent = gatewayData.data.upi_intent || upiIntent;
        } else {
          console.warn('FamGateway returned non-success, falling back to local order:', gatewayData);
        }
      } catch (gwErr) {
        console.error('FamGateway connection error, proceeding with sandbox payment order:', gwErr);
      }
    }

    // Generate high-resolution local QR Data URL as a fail-safe
    let qrDataUrl = '';
    try {
      qrDataUrl = await QRCode.toDataURL(upiIntent, {
        margin: 1,
        width: 320,
        color: {
          dark: '#1e1035',
          light: '#ffffff',
        },
      });
    } catch (e) {
      console.error('QR generation failed:', e);
    }

    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes session

    const transaction: PaymentTransaction = {
      orderId,
      internalId,
      appId: app.id,
      appName: app.name,
      amount: requestedAmount,
      payableAmount,
      upiId,
      status: 'PENDING',
      customerName,
      customerPhone,
      customerEmail,
      qrUrl: qrUrl,
      checkoutUrl,
      upiIntent,
      createdAt: Date.now(),
      expiresAt,
    };

    db.addPayment(transaction);

    res.json({
      status: 'success',
      data: {
        order_id: orderId,
        internal_id: internalId,
        app_id: app.id,
        app_name: app.name,
        amount: requestedAmount,
        payable_amount: payableAmount,
        upi_id: upiId,
        qr_url: qrUrl,
        qr_data_url: qrDataUrl,
        checkout_url: checkoutUrl,
        upi_intent: upiIntent,
        expires_at: expiresAt,
        is_live_gateway: isLiveKeyConfigured(),
      },
    });
  } catch (err: any) {
    console.error('Error creating order:', err);
    res.status(500).json({ error: 'Internal server error creating payment order' });
  }
});

/**
 * GET /api/payment/checkout-status?order_id=ORDER_ID
 * Public safe status polling endpoint (polled every 3-5 seconds by frontend).
 */
paymentRouter.get('/checkout-status', async (req: Request, res: Response): Promise<void> => {
  try {
    const orderId = req.query.order_id as string;
    if (!orderId) {
      res.status(400).json({ status: 'error', message: 'order_id is required' });
      return;
    }

    const payment = db.getPaymentByOrderId(orderId);
    if (!payment) {
      res.status(404).json({ status: 'error', message: 'Order not found' });
      return;
    }

    // Check expiry
    if (payment.status === 'PENDING' && Date.now() > payment.expiresAt) {
      db.updatePayment(orderId, { status: 'EXPIRED' });
      res.json({ status: 'expired', order_id: orderId });
      return;
    }

    // If already marked success
    if (payment.status === 'SUCCESS') {
      res.json({
        status: 'success',
        order_id: payment.orderId,
        utr: payment.utr,
        sender_name: payment.senderName || payment.customerName || 'Customer',
        download_token: payment.downloadToken,
        app_id: payment.appId,
      });
      return;
    }

    // If live API is configured, poll FamGateway safe public status endpoint
    if (isLiveKeyConfigured() && payment.status === 'PENDING') {
      try {
        const gwStatusRes = await fetch(
          `${FAMGATEWAY_BASE}/api/checkout-status.php?order_id=${encodeURIComponent(orderId)}`
        );
        const gwStatus = (await gwStatusRes.json()) as any;

        if (gwStatus.status === 'success') {
          // Verify on server before granting download token
          const verified = await serverVerifyOrder(payment, gwStatus.utr, gwStatus.sender_name);
          if (verified) {
            const updated = db.getPaymentByOrderId(orderId);
            res.json({
              status: 'success',
              order_id: payment.orderId,
              utr: updated?.utr,
              sender_name: updated?.senderName,
              download_token: updated?.downloadToken,
              app_id: payment.appId,
            });
            return;
          }
        } else if (gwStatus.status === 'expired') {
          db.updatePayment(orderId, { status: 'EXPIRED' });
          res.json({ status: 'expired', order_id: orderId });
          return;
        }
      } catch (err) {
        // Network or upstream error, fallback to current stored state
      }
    }

    res.json({
      status: payment.status.toLowerCase(),
      order_id: payment.orderId,
    });
  } catch (err) {
    console.error('Error checking payment status:', err);
    res.status(500).json({ status: 'error', message: 'Failed to check status' });
  }
});

/**
 * Helper to execute authoritative server-side verification with FamGateway
 */
async function serverVerifyOrder(
  payment: PaymentTransaction,
  incomingUtr?: string,
  incomingSenderName?: string
): Promise<boolean> {
  let verifiedUtr = incomingUtr;
  let verifiedTransactionId = `TXN_${Date.now()}`;
  let verifiedAmount = payment.payableAmount;
  let verifiedSenderName = incomingSenderName;

  if (isLiveKeyConfigured()) {
    try {
      const verifyRes = await fetch(
        `${FAMGATEWAY_BASE}/api/verify-order.php?order_id=${encodeURIComponent(payment.orderId)}`,
        {
          headers: {
            'X-Api-Key': FAMGATEWAY_KEY,
          },
        }
      );
      const verifyData = (await verifyRes.json()) as any;
      if (verifyData.status !== 'success' || !verifyData.data) {
        console.warn('Server verification rejected by FamGateway:', verifyData);
        return false;
      }
      verifiedUtr = verifyData.data.utr || verifiedUtr;
      verifiedTransactionId = verifyData.data.transaction_id || verifiedTransactionId;
      verifiedAmount = parseFloat(verifyData.data.amount);
      verifiedSenderName = verifyData.data.sender_name || verifiedSenderName;
    } catch (err) {
      console.error('FamGateway server verification request failed:', err);
      return false;
    }
  }

  // 1. Amount validation
  if (!validatePaymentAmount(verifiedAmount, payment.payableAmount)) {
    console.error('Payment amount mismatch:', { verifiedAmount, expected: payment.payableAmount });
    return false;
  }

  // 2. Duplicate UTR check
  const allPayments = db.getPayments();
  if (isDuplicateUtr(verifiedUtr, payment.orderId, allPayments)) {
    console.error('Duplicate UTR detected! Rejected:', verifiedUtr);
    return false;
  }

  // 3. Issue secure 30-minute download token
  const downloadToken = createDownloadToken(payment.appId, payment.orderId, DOWNLOAD_SECRET);

  db.updatePayment(payment.orderId, {
    status: 'SUCCESS',
    paidAt: Date.now(),
    utr: verifiedUtr || `UTR${Date.now()}`,
    transactionId: verifiedTransactionId,
    senderName: verifiedSenderName || 'Verified Payer',
    downloadToken,
  });

  // Log in admin audit logs
  db.addAuditLog(
    'PAYMENT_SUCCESS',
    'system',
    '127.0.0.1',
    `Verified order ${payment.orderId} for ₹${payment.payableAmount} (App: ${payment.appName}, UTR: ${verifiedUtr})`
  );

  return true;
}

/**
 * POST /api/payment/verify-order
 * Authoritative server-side verification request
 */
paymentRouter.post('/verify-order', async (req: Request, res: Response): Promise<void> => {
  try {
    const { order_id } = req.body;
    if (!order_id) {
      res.status(400).json({ status: 'error', message: 'order_id is required' });
      return;
    }

    const payment = db.getPaymentByOrderId(order_id);
    if (!payment) {
      res.status(404).json({ status: 'error', message: 'Order not found' });
      return;
    }

    if (payment.status === 'SUCCESS') {
      res.json({
        status: 'success',
        data: {
          order_id: payment.orderId,
          transaction_id: payment.transactionId,
          amount: payment.payableAmount,
          utr: payment.utr,
          sender_name: payment.senderName,
          download_token: payment.downloadToken,
        },
      });
      return;
    }

    const verified = await serverVerifyOrder(payment);
    if (verified) {
      const updated = db.getPaymentByOrderId(order_id);
      res.json({
        status: 'success',
        data: {
          order_id: updated?.orderId,
          transaction_id: updated?.transactionId,
          amount: updated?.payableAmount,
          utr: updated?.utr,
          sender_name: updated?.senderName,
          download_token: updated?.downloadToken,
        },
      });
    } else {
      res.status(400).json({ status: 'error', message: 'Payment could not be verified' });
    }
  } catch (err) {
    console.error('Error verifying order:', err);
    res.status(500).json({ status: 'error', message: 'Verification error' });
  }
});

/**
 * POST /api/famgateway-webhook
 * Official FamGateway Webhook Handler with HMAC-SHA256 signature verification.
 */
paymentRouter.post('/famgateway-webhook', async (req: Request, res: Response): Promise<void> => {
  try {
    const signature = req.headers['x-famgateway-signature'] as string;
    const rawBody = JSON.stringify(req.body);

    if (isLiveKeyConfigured()) {
      if (!signature) {
        console.warn('Webhook received without X-FamGateway-Signature header');
        res.status(401).json({ error: 'Signature header missing' });
        return;
      }

      const expectedSig = crypto
        .createHmac('sha256', FAMGATEWAY_KEY)
        .update(rawBody)
        .digest('hex');

      if (signature !== expectedSig) {
        console.warn('Invalid webhook signature received');
        res.status(401).json({ error: 'Invalid HMAC signature' });
        return;
      }
    }

    const payload = req.body;
    if (payload.event !== 'payment.success' || payload.status !== 'success') {
      res.status(200).json({ message: 'Event ignored' });
      return;
    }

    const orderId = payload.order_id;
    const payment = db.getPaymentByOrderId(orderId);
    if (!payment) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }

    // Verify amount
    const paidAmount = parseFloat(payload.payable_amount || payload.amount);
    if (!validatePaymentAmount(paidAmount, payment.payableAmount)) {
      res.status(400).json({ error: 'Amount mismatch' });
      return;
    }

    // Check duplicate UTR
    const utr = payload.utr;
    if (isDuplicateUtr(utr, payment.orderId, db.getPayments())) {
      console.warn('Duplicate UTR in webhook, rejecting duplicate processing:', utr);
      res.status(409).json({ error: 'Duplicate UTR already processed' });
      return;
    }

    // Issue download token
    const downloadToken = createDownloadToken(payment.appId, payment.orderId, DOWNLOAD_SECRET);

    db.updatePayment(orderId, {
      status: 'SUCCESS',
      paidAt: Date.now(),
      utr: utr || `UTR${Date.now()}`,
      transactionId: payload.transaction_id || `TXN${Date.now()}`,
      senderName: payload.sender_name || 'Webhook Verified',
      downloadToken,
    });

    db.addAuditLog(
      'WEBHOOK_SUCCESS',
      'famgateway',
      req.ip || 'gateway',
      `Webhook verified order ${orderId} for ₹${paidAmount} (UTR: ${utr})`
    );

    res.status(200).json({ status: 'ok', message: 'Payment confirmed via webhook' });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(500).json({ error: 'Webhook processing failure' });
  }
});

/**
 * POST /api/payment/simulate-test-pay
 * Sandbox helper for developer testing and verification in staging/demo mode.
 */
paymentRouter.post('/simulate-test-pay', async (req: Request, res: Response): Promise<void> => {
  try {
    const { order_id } = req.body;
    if (!order_id) {
      res.status(400).json({ error: 'order_id is required' });
      return;
    }

    const payment = db.getPaymentByOrderId(order_id);
    if (!payment) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }

    const testUtr = `420${Math.floor(100000000 + Math.random() * 900000000)}`;
    const testTxn = `FMP${Math.floor(100000000 + Math.random() * 900000000)}`;

    const downloadToken = createDownloadToken(payment.appId, payment.orderId, DOWNLOAD_SECRET);

    db.updatePayment(order_id, {
      status: 'SUCCESS',
      paidAt: Date.now(),
      utr: testUtr,
      transactionId: testTxn,
      senderName: payment.customerName || 'Test Customer (FamPay)',
      downloadToken,
    });

    db.addAuditLog(
      'TEST_PAYMENT_SIMULATED',
      'demo_tester',
      req.ip || '127.0.0.1',
      `Simulated successful payment for order ${order_id} (UTR: ${testUtr})`
    );

    res.json({
      status: 'success',
      order_id,
      utr: testUtr,
      transaction_id: testTxn,
      download_token: downloadToken,
    });
  } catch (err) {
    console.error('Test simulation error:', err);
    res.status(500).json({ error: 'Simulation failed' });
  }
});
