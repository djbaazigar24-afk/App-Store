import { Router, Request, Response, NextFunction } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { db } from '../db';
import { AppItem, WebsiteSettings } from '../types';

export const adminRouter = Router();

// Rate limiting state for brute-force protection
const failedAttempts = new Map<string, { count: number; blockedUntil: number }>();

function checkRateLimit(ip: string): boolean {
  const record = failedAttempts.get(ip);
  if (!record) return true;
  if (Date.now() < record.blockedUntil) {
    return false; // Still blocked
  }
  if (Date.now() >= record.blockedUntil) {
    failedAttempts.delete(ip);
    return true;
  }
  return true;
}

function recordFailedAttempt(ip: string): void {
  const record = failedAttempts.get(ip) || { count: 0, blockedUntil: 0 };
  record.count += 1;
  if (record.count >= 5) {
    record.blockedUntil = Date.now() + 15 * 60 * 1000; // 15 min lock
  }
  failedAttempts.set(ip, record);
}

function clearFailedAttempts(ip: string): void {
  failedAttempts.delete(ip);
}

/**
 * Admin Authentication Middleware
 */
export function requireAdminAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization || (req.headers['x-admin-token'] as string);
  const token = authHeader ? authHeader.replace(/^Bearer\s+/i, '') : null;

  if (!token) {
    res.status(401).json({ error: 'Unauthorized. Admin session token required.' });
    return;
  }

  const isValid = db.validateSession(token);
  if (!isValid) {
    res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
    return;
  }

  next();
}

/**
 * POST /api/admin/login
 * Validates password and generates session token
 */
adminRouter.post('/login', (req: Request, res: Response): void => {
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const { password } = req.body;

  if (!checkRateLimit(ip)) {
    const record = failedAttempts.get(ip);
    const waitSeconds = Math.ceil(((record?.blockedUntil || 0) - Date.now()) / 1000);
    res.status(429).json({
      error: `Too many failed login attempts. Terminal locked. Try again in ${waitSeconds}s.`,
    });
    return;
  }

  if (!password || typeof password !== 'string') {
    res.status(400).json({ error: 'Password is required' });
    return;
  }

  const isMatch = db.verifyPassword(password);
  if (!isMatch) {
    recordFailedAttempt(ip);
    db.addAuditLog('LOGIN_FAILED', 'anonymous', ip, 'Incorrect admin password attempt');
    res.status(401).json({ error: 'Invalid admin credentials' });
    return;
  }

  clearFailedAttempts(ip);
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const session = db.createSession(ip, userAgent);

  db.addAuditLog('LOGIN_SUCCESS', 'admin', ip, `Admin logged in from ${userAgent.substring(0, 40)}`);

  res.json({
    status: 'success',
    token: session.sessionId,
    expiresAt: session.expiresAt,
  });
});

/**
 * GET /api/admin/verify-session
 */
adminRouter.get('/verify-session', requireAdminAuth, (req: Request, res: Response): void => {
  res.json({ status: 'valid' });
});

/**
 * POST /api/admin/logout
 */
adminRouter.post('/logout', (req: Request, res: Response): void => {
  const authHeader = req.headers.authorization || (req.headers['x-admin-token'] as string);
  const token = authHeader ? authHeader.replace(/^Bearer\s+/i, '') : null;
  if (token) {
    db.revokeSession(token);
    db.addAuditLog('LOGOUT', 'admin', req.ip || '127.0.0.1', 'Admin signed out');
  }
  res.json({ status: 'success' });
});

/**
 * POST /api/admin/change-password
 */
adminRouter.post('/change-password', requireAdminAuth, (req: Request, res: Response): void => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    res.status(400).json({ error: 'Current password and new password are required' });
    return;
  }

  if (newPassword.length < 5) {
    res.status(400).json({ error: 'New password must be at least 5 characters long' });
    return;
  }

  if (!db.verifyPassword(currentPassword)) {
    res.status(401).json({ error: 'Current password is incorrect' });
    return;
  }

  db.setAdminPassword(newPassword);
  db.addAuditLog('PASSWORD_CHANGED', 'admin', req.ip || '127.0.0.1', 'Admin password changed');

  // Issue new session for current user
  const newSession = db.createSession(req.ip || '127.0.0.1', req.headers['user-agent'] || '');
  res.json({
    status: 'success',
    message: 'Password changed successfully',
    newToken: newSession.sessionId,
  });
});

/**
 * GET /api/admin/analytics
 */
adminRouter.get('/analytics', requireAdminAuth, (req: Request, res: Response): void => {
  const apps = db.getApps(true);
  const payments = db.getPayments();
  const visitorCount = db.getVisitorCount();

  const totalDownloads = apps.reduce((sum, a) => sum + (a.downloadsCount || 0), 0);
  const successfulPayments = payments.filter((p) => p.status === 'SUCCESS');
  const pendingPayments = payments.filter((p) => p.status === 'PENDING');
  const expiredPayments = payments.filter((p) => p.status === 'EXPIRED' || p.status === 'FAILED');

  const totalRevenue = successfulPayments.reduce((sum, p) => sum + p.payableAmount, 0);

  // Category counts
  const categoryCounts: Record<string, number> = {};
  apps.forEach((a) => {
    categoryCounts[a.category] = (categoryCounts[a.category] || 0) + 1;
  });

  res.json({
    totalVisitors: visitorCount,
    totalApplications: apps.length,
    publishedApplications: apps.filter((a) => a.published).length,
    totalDownloads,
    totalRevenue,
    successfulPaymentsCount: successfulPayments.length,
    pendingPaymentsCount: pendingPayments.length,
    expiredPaymentsCount: expiredPayments.length,
    recentTransactions: payments.slice(0, 15),
    categoryCounts,
  });
});

/**
 * GET /api/admin/apps (all apps, including draft/unpublished)
 */
adminRouter.get('/apps', requireAdminAuth, (req: Request, res: Response): void => {
  const apps = db.getApps(true);
  res.json(apps);
});

/**
 * POST /api/admin/upload-file
 * Handles real binary upload (base64) for APK files, App Icons, and Screenshots
 */
adminRouter.post('/upload-file', requireAdminAuth, (req: Request, res: Response): void => {
  try {
    const { filename, fileBase64, fileType } = req.body;
    if (!filename || !fileBase64) {
      res.status(400).json({ error: 'filename and fileBase64 are required' });
      return;
    }

    const uploadsDir = path.resolve(process.cwd(), 'data', 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    // Strip data URL header if present (e.g. "data:image/png;base64,...")
    const cleanBase64 = fileBase64.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(cleanBase64, 'base64');

    // Generate safe unique filename
    const ext = path.extname(filename) || (fileType === 'apk' ? '.apk' : '.png');
    const baseName = path.basename(filename, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const safeFilename = `${Date.now()}_${baseName}${ext}`;
    const targetPath = path.join(uploadsDir, safeFilename);

    fs.writeFileSync(targetPath, buffer);

    const sizeMb = parseFloat((buffer.length / (1024 * 1024)).toFixed(2));
    const fileUrl = `/uploads/${safeFilename}`;

    db.addAuditLog(
      'FILE_UPLOADED',
      'admin',
      req.ip || '127.0.0.1',
      `Uploaded ${fileType || 'file'}: "${safeFilename}" (${sizeMb} MB)`
    );

    res.json({
      status: 'success',
      filename: safeFilename,
      fileUrl,
      sizeMb: sizeMb > 0 ? sizeMb : 0.1,
    });
  } catch (err: any) {
    console.error('File upload error:', err);
    res.status(500).json({ error: 'Failed to process file upload' });
  }
});

/**
 * POST /api/admin/apps (create new app)
 */
adminRouter.post('/apps', requireAdminAuth, (req: Request, res: Response): void => {
  const {
    name,
    packageName,
    version,
    sizeMb,
    category,
    price,
    shortDesc,
    description,
    features,
    iconUrl,
    bannerUrl,
    screenshots,
    apkFileName,
    apkDownloadUrl,
    published,
    downloadsEnabled,
    isTrending,
    isPopular,
    isVip,
  } = req.body;

  if (!name || !category) {
    res.status(400).json({ error: 'Name and category are required' });
    return;
  }

  const newApp = db.addApp({
    name,
    packageName: packageName || `com.djbaazigar.${name.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
    version: version || '1.0.0',
    sizeMb: parseFloat(sizeMb) || 25.0,
    category,
    price: parseFloat(price) || 0,
    rating: 4.8,
    downloadsCount: 0,
    iconUrl: iconUrl || '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
    bannerUrl: bannerUrl || '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    screenshots: Array.isArray(screenshots) ? screenshots : [],
    shortDesc: shortDesc || 'High quality VIP Android mod by DJ Baazigar',
    description: description || 'Premium Android VIP application.',
    features: Array.isArray(features) ? features : ['VIP Unlocked', 'Clean & Virus Free'],
    apkFileName: apkFileName || undefined,
    apkDownloadUrl: apkDownloadUrl || undefined,
    published: published !== undefined ? Boolean(published) : true,
    downloadsEnabled: downloadsEnabled !== undefined ? Boolean(downloadsEnabled) : true,
    isTrending: Boolean(isTrending),
    isPopular: Boolean(isPopular),
    isVip: Boolean(isVip),
  });

  db.addAuditLog('APP_CREATED', 'admin', req.ip || '127.0.0.1', `Created application "${newApp.name}"`);

  res.json({ status: 'success', data: newApp });
});

/**
 * PUT /api/admin/apps/:id
 */
adminRouter.put('/apps/:id', requireAdminAuth, (req: Request, res: Response): void => {
  const id = req.params.id;
  const updates = req.body;

  const updated = db.updateApp(id, updates);
  if (!updated) {
    res.status(404).json({ error: 'App not found' });
    return;
  }

  db.addAuditLog('APP_UPDATED', 'admin', req.ip || '127.0.0.1', `Updated application "${updated.name}"`);

  res.json({ status: 'success', data: updated });
});

/**
 * DELETE /api/admin/apps/:id
 */
adminRouter.delete('/apps/:id', requireAdminAuth, (req: Request, res: Response): void => {
  const id = req.params.id;
  const app = db.getAppById(id);
  const success = db.deleteApp(id);
  if (!success) {
    res.status(404).json({ error: 'App not found' });
    return;
  }

  db.addAuditLog('APP_DELETED', 'admin', req.ip || '127.0.0.1', `Deleted application "${app?.name || id}"`);

  res.json({ status: 'success' });
});

/**
 * GET & PUT /api/admin/settings
 */
adminRouter.get('/settings', requireAdminAuth, (req: Request, res: Response): void => {
  res.json(db.getSettings());
});

adminRouter.put('/settings', requireAdminAuth, (req: Request, res: Response): void => {
  const updates: Partial<WebsiteSettings> = req.body;
  const updated = db.updateSettings(updates);

  db.addAuditLog('SETTINGS_UPDATED', 'admin', req.ip || '127.0.0.1', 'Updated website customization');

  res.json({ status: 'success', data: updated });
});

/**
 * GET /api/admin/payments
 */
adminRouter.get('/payments', requireAdminAuth, (req: Request, res: Response): void => {
  const status = req.query.status as string;
  const query = (req.query.q as string)?.toLowerCase();

  let payments = db.getPayments();

  if (status && status !== 'ALL') {
    payments = payments.filter((p) => p.status === status.toUpperCase());
  }

  if (query) {
    payments = payments.filter(
      (p) =>
        p.orderId.toLowerCase().includes(query) ||
        p.appName.toLowerCase().includes(query) ||
        (p.utr && p.utr.toLowerCase().includes(query)) ||
        (p.customerName && p.customerName.toLowerCase().includes(query)) ||
        (p.transactionId && p.transactionId.toLowerCase().includes(query))
    );
  }

  res.json(payments);
});

/**
 * POST /api/admin/payments/export (CSV)
 */
adminRouter.post('/payments/export', requireAdminAuth, (req: Request, res: Response): void => {
  const payments = db.getPayments();

  const headers = ['Order ID', 'Internal ID', 'App Name', 'Amount (INR)', 'Status', 'UTR', 'Transaction ID', 'Payer Name', 'Created At', 'Paid At'];
  const rows = payments.map((p) => [
    p.orderId,
    p.internalId,
    `"${(p.appName || '').replace(/"/g, '""')}"`,
    p.payableAmount,
    p.status,
    p.utr || '',
    p.transactionId || '',
    `"${(p.senderName || p.customerName || '').replace(/"/g, '""')}"`,
    new Date(p.createdAt).toISOString(),
    p.paidAt ? new Date(p.paidAt).toISOString() : '',
  ]);

  const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="DJBaazigar_Transactions.csv"');
  res.send(csv);
});

/**
 * GET /api/admin/audit-logs
 */
adminRouter.get('/audit-logs', requireAdminAuth, (req: Request, res: Response): void => {
  res.json(db.getAuditLogs());
});

/**
 * GET /api/admin/sessions & POST /api/admin/revoke-sessions
 */
adminRouter.get('/sessions', requireAdminAuth, (req: Request, res: Response): void => {
  res.json(db.getSessions());
});

adminRouter.post('/revoke-sessions', requireAdminAuth, (req: Request, res: Response): void => {
  db.revokeAllSessions();
  db.addAuditLog('SESSIONS_REVOKED', 'admin', req.ip || '127.0.0.1', 'Revoked all active admin sessions');
  res.json({ status: 'success', message: 'All sessions revoked' });
});
