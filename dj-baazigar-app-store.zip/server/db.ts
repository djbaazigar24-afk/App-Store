import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { AppItem, PaymentTransaction, WebsiteSettings, AdminSession, AuditLog } from './types';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

// Default initial state
interface DatabaseStore {
  apps: AppItem[];
  payments: PaymentTransaction[];
  settings: WebsiteSettings;
  adminPasswordHash: string;
  adminSalt: string;
  sessions: AdminSession[];
  auditLogs: AuditLog[];
  visitorCount: number;
}

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

const defaultSalt = 'djbaazigar_salt_2026';
const defaultHash = hashPassword('ADMIN', defaultSalt);

const defaultSeedApps: AppItem[] = [
  {
    id: 'app-dj-baazigar-vip',
    name: 'DJ Baazigar Music Modz VIP',
    packageName: 'com.djbaazigar.modzvip',
    version: '4.8.2',
    sizeMb: 58.4,
    category: 'DJ & Music Modz',
    price: 99,
    rating: 4.95,
    downloadsCount: 14280,
    iconUrl: '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
    bannerUrl: '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    screenshots: [
      '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
      '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
    ],
    shortDesc: 'Ultimate mobile DJ workstation with unlocked VIP sound packs, auto-drop engine & zero latency.',
    description: 'DJ Baazigar Music Modz VIP transforms your Android device into a powerhouse club sound console. Built with custom dual-deck mixing, dynamic BPM master sync, 32-band parametric equalizer, and unlocked VIP drops curated by DJ Baazigar himself.',
    features: [
      'Dual Ultra-Responsive Virtual Turntables with Scratch FX',
      'Real-time BPM Auto-Sync & Key Lock Engine',
      'Over 250+ Exclusive High-Energy DJ Drops & Vocal Chants',
      'Studio Grade 32-Band Equalizer with Deep Sub-Bass Booster',
      'Zero-Latency Audio Engine tested on Snapdragon & MediaTek',
      'Ad-Free VIP Lifetime Unlocked Pro License'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: true,
    isPopular: true,
    isVip: true,
    createdAt: Date.now() - 86400000 * 30,
    updatedAt: Date.now() - 86400000 * 2,
  },
  {
    id: 'app-bass-booster-8d',
    name: 'Bass Booster Extreme 8D Audio',
    packageName: 'com.djbaazigar.bass8d',
    version: '3.6.0',
    sizeMb: 34.2,
    category: 'VIP Audio Tools',
    price: 49,
    rating: 4.88,
    downloadsCount: 28540,
    iconUrl: '/src/assets/images/app_bass_booster_8d_1793910719183.jpg',
    screenshots: [
      '/src/assets/images/app_bass_booster_8d_1793910719183.jpg',
      '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    ],
    shortDesc: 'Punchy sub-woofer acoustic booster with 8D spatial 360-degree rotational surround sound.',
    description: 'Experience ground-shaking low frequency amplification without distortion. Bass Booster Extreme 8D integrates hardware-accelerated DSP algorithms to render true 360-degree spatial sound across headphones and car audio systems.',
    features: [
      'Hardware Sub-Bass Resonance Maximizer (20Hz - 80Hz)',
      '360° Rotational 8D Binaural Sound Stage',
      'Car Stereo & Bluetooth Speaker High-Power Boost Mode',
      'Smart AGC (Automatic Gain Control) to prevent speaker blow',
      'Custom Presets for Bollywood, Bhojpuri, Club, and Trap'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: true,
    isPopular: true,
    isVip: true,
    createdAt: Date.now() - 86400000 * 45,
    updatedAt: Date.now() - 86400000 * 5,
  },
  {
    id: 'app-game-booster-pro',
    name: 'Android VIP Game Turbo Booster',
    packageName: 'com.djbaazigar.gameturbo',
    version: '5.1.4',
    sizeMb: 24.8,
    category: 'Game Boosters',
    price: 79,
    rating: 4.91,
    downloadsCount: 39120,
    iconUrl: '/src/assets/images/app_game_booster_pro_1793910720057.jpg',
    screenshots: [
      '/src/assets/images/app_game_booster_pro_1793910720057.jpg',
      '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    ],
    shortDesc: 'Unlock 90/120 FPS, stabilize thermal throttling and optimize RAM for intense mobile gaming.',
    description: 'Engineered specifically for BGMI, Free Fire, and high-demand Android games. Clears background micro-processes, optimizes GPU shader caches, and locks CPU frequency to prevent sudden mid-match frame drops.',
    features: [
      'Unlocks 90 FPS & Extreme Frame Rate options',
      'Direct GPU Shader Cache pre-compilation',
      'Ping Stabilizer & Background Network Limiter',
      'Thermal Throttle Controller for sustained gameplay',
      'Crosshair HUD overlay with custom colors'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: true,
    isPopular: true,
    isVip: true,
    createdAt: Date.now() - 86400000 * 60,
    updatedAt: Date.now() - 86400000 * 1,
  },
  {
    id: 'app-beat-master-fx',
    name: 'Auto Beat DJ Looper & Voice FX',
    packageName: 'com.djbaazigar.beatmaster',
    version: '2.9.1',
    sizeMb: 46.7,
    category: 'DJ & Music Modz',
    price: 0, // Free
    rating: 4.79,
    downloadsCount: 52400,
    iconUrl: '/src/assets/images/app_beat_master_fx_1793910719987.jpg',
    screenshots: [
      '/src/assets/images/app_beat_master_fx_1793910719987.jpg',
      '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    ],
    shortDesc: 'Create instant remixes on Android with one-tap rhythmic loop pads and live pitch tuning.',
    description: 'Auto Beat DJ Looper is the go-to tool for mobile remixers and vocalists. Jam with 64 dynamic touch sample pads, apply real-time echo and flanger effects, and export high-definition WAV stems instantly.',
    features: [
      '64-Pad Interactive Electro Pad Board',
      'Live Mic Input with Real-time Auto-Pitch & Reverb FX',
      'Pre-loaded Bollywood & EDM Rhythms and Dholak Grooves',
      'High-Resolution 24-Bit WAV Stem Audio Recorder',
      '100% Free Forever - Community Special Edition'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: false,
    isPopular: true,
    isVip: false,
    createdAt: Date.now() - 86400000 * 90,
    updatedAt: Date.now() - 86400000 * 12,
  },
  {
    id: 'app-jomraj-sound-fx',
    name: 'Jomraj Pro Audio Sound Effects Studio',
    packageName: 'com.djbaazigar.jomrajfx',
    version: '1.9.0',
    sizeMb: 28.5,
    category: 'VIP Audio Tools',
    price: 39,
    rating: 4.84,
    downloadsCount: 19800,
    iconUrl: '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
    screenshots: [
      '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
      '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
    ],
    shortDesc: 'Over 500+ club horn, laser sweeps, sirens and stutter vocal samples for stage performers.',
    description: 'Equip your live stage sound kit with DJ Baazigar signature sound effects. Direct shortcut floating widget allows triggering sirens, air horns, and reverse cymbals over any ongoing music player.',
    features: [
      'Floating Quick-Trigger DJ Sound Board overlay',
      'Stereo Laser sweeps, Dub Siren, and Air Horns',
      'Pitch-bend wheel and stutter loop repeater',
      'Custom sample recorder to load your own MP3 sounds'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: false,
    isPopular: false,
    isVip: true,
    createdAt: Date.now() - 86400000 * 20,
    updatedAt: Date.now() - 86400000 * 4,
  },
  {
    id: 'app-apk-anti-ban-guardian',
    name: 'VIP Mod Safe Guardian & Cleaner',
    packageName: 'com.djbaazigar.guardian',
    version: '2.1.0',
    sizeMb: 18.2,
    category: 'Utility Tools',
    price: 0, // Free
    rating: 4.75,
    downloadsCount: 31200,
    iconUrl: '/src/assets/images/app_game_booster_pro_1793910720057.jpg',
    screenshots: [
      '/src/assets/images/app_game_booster_pro_1793910720057.jpg',
    ],
    shortDesc: 'Deep cleaner for APK cache, obsolete OBB files and security token permission audits.',
    description: 'Keep your modded applications running safely without cache corruption or unexpected background crashes. Cleans residual logs and inspects package signatures with one tap.',
    features: [
      'APK Signature & Checksum Integrity Verifier',
      'OBB & Cache File Garbage Collector',
      'Background Telemetry Blocking Engine',
      'Free Utility Tool for DJ Baazigar community'
    ],
    published: true,
    downloadsEnabled: true,
    isTrending: false,
    isPopular: false,
    isVip: false,
    createdAt: Date.now() - 86400000 * 15,
    updatedAt: Date.now() - 86400000 * 3,
  }
];

const defaultSettings: WebsiteSettings = {
  siteName: 'DJ BAAZIGAR APP STORE',
  siteTitle: 'DJ Baazigar VIP Android Apps & Modz Marketplace',
  siteDescription: 'Exclusive premium Android Modz, DJ Mixers, and VIP Tools with instant UPI verification and high-speed APK downloads.',
  announcementBanner: '⚡ FLASH SALE: DJ Baazigar Music Modz VIP v4.8 is now live! Download with instant UPI unlock.',
  announcementEnabled: true,
  heroBadge: 'OFFICIAL DJ BAAZIGAR MARKETPLACE',
  heroHeadline: 'NEXT-GEN VIP ANDROID MODZ & AUDIO SUITES',
  heroSubtitle: 'Download high-performance DJ mixers, VIP gaming modz, and exclusive audio tools. 100% Virus-Free & Instant UPI Access.',
  primaryColor: '#a855f7',
  secondaryColor: '#3b82f6',
  contactWhatsApp: '+91 98765 43210',
  contactTelegram: '@dj_baazigar_official',
  contactEmail: 'avijit86259779@gmail.com',
  contactPhone: '+91 98765 43210',
  maintenanceMode: false,
  allowDirectFreeDownloads: true,
  currencySymbol: '₹',
};

class Database {
  private store: DatabaseStore;

  constructor() {
    this.store = this.loadData();
  }

  private loadData(): DatabaseStore {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          apps: parsed.apps || defaultSeedApps,
          payments: parsed.payments || [],
          settings: parsed.settings || defaultSettings,
          adminPasswordHash: parsed.adminPasswordHash || defaultHash,
          adminSalt: parsed.adminSalt || defaultSalt,
          sessions: parsed.sessions || [],
          auditLogs: parsed.auditLogs || [],
          visitorCount: parsed.visitorCount || 4280,
        };
      }
    } catch (err) {
      console.error('Error reading database file, using defaults:', err);
    }

    const initial: DatabaseStore = {
      apps: defaultSeedApps,
      payments: [],
      settings: defaultSettings,
      adminPasswordHash: defaultHash,
      adminSalt: defaultSalt,
      sessions: [],
      auditLogs: [
        {
          id: 'log-init',
          action: 'SYSTEM_INITIALIZED',
          adminId: 'system',
          ip: '127.0.0.1',
          details: 'DJ Baazigar App Store database initialized successfully.',
          timestamp: Date.now(),
        },
      ],
      visitorCount: 4280,
    };

    this.saveData(initial);
    return initial;
  }

  private saveData(data: DatabaseStore) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public persist() {
    this.saveData(this.store);
  }

  // --- Visitor counter ---
  public incrementVisitor() {
    this.store.visitorCount += 1;
    this.persist();
    return this.store.visitorCount;
  }

  public getVisitorCount(): number {
    return this.store.visitorCount;
  }

  // --- Apps ---
  public getApps(includeUnpublished = false): AppItem[] {
    if (includeUnpublished) return this.store.apps;
    return this.store.apps.filter((a) => a.published);
  }

  public getAppById(id: string): AppItem | undefined {
    return this.store.apps.find((a) => a.id === id);
  }

  public addApp(app: Omit<AppItem, 'id' | 'createdAt' | 'updatedAt'>): AppItem {
    const id = `app-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newApp: AppItem = {
      ...app,
      id,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    this.store.apps.unshift(newApp);
    this.persist();
    return newApp;
  }

  public updateApp(id: string, updates: Partial<AppItem>): AppItem | null {
    const idx = this.store.apps.findIndex((a) => a.id === id);
    if (idx === -1) return null;
    const existing = this.store.apps[idx];
    const updated: AppItem = {
      ...existing,
      ...updates,
      id: existing.id,
      updatedAt: Date.now(),
    };
    this.store.apps[idx] = updated;
    this.persist();
    return updated;
  }

  public deleteApp(id: string): boolean {
    const idx = this.store.apps.findIndex((a) => a.id === id);
    if (idx === -1) return false;
    this.store.apps.splice(idx, 1);
    this.persist();
    return true;
  }

  public incrementDownload(id: string) {
    const app = this.getAppById(id);
    if (app) {
      app.downloadsCount = (app.downloadsCount || 0) + 1;
      this.persist();
    }
  }

  // --- Payments ---
  public getPayments(): PaymentTransaction[] {
    return this.store.payments;
  }

  public getPaymentByOrderId(orderId: string): PaymentTransaction | undefined {
    return this.store.payments.find((p) => p.orderId === orderId);
  }

  public addPayment(payment: PaymentTransaction): PaymentTransaction {
    this.store.payments.unshift(payment);
    this.persist();
    return payment;
  }

  public updatePayment(
    orderId: string,
    updates: Partial<PaymentTransaction>
  ): PaymentTransaction | null {
    const idx = this.store.payments.findIndex((p) => p.orderId === orderId);
    if (idx === -1) return null;
    const updated = { ...this.store.payments[idx], ...updates };
    this.store.payments[idx] = updated;
    this.persist();
    return updated;
  }

  // --- Settings ---
  public getSettings(): WebsiteSettings {
    return this.store.settings;
  }

  public updateSettings(updates: Partial<WebsiteSettings>): WebsiteSettings {
    this.store.settings = { ...this.store.settings, ...updates };
    this.persist();
    return this.store.settings;
  }

  // --- Admin Security ---
  public verifyPassword(password: string): boolean {
    const calculated = hashPassword(password, this.store.adminSalt);
    return crypto.timingSafeEqual(
      Buffer.from(calculated),
      Buffer.from(this.store.adminPasswordHash)
    );
  }

  public setAdminPassword(newPassword: string): void {
    const newSalt = crypto.randomBytes(16).toString('hex');
    const newHash = hashPassword(newPassword, newSalt);
    this.store.adminSalt = newSalt;
    this.store.adminPasswordHash = newHash;
    // Revoke existing sessions when password changes
    this.store.sessions = [];
    this.persist();
  }

  public createSession(ip: string, userAgent: string): AdminSession {
    const session: AdminSession = {
      sessionId: crypto.randomBytes(32).toString('hex'),
      ip,
      userAgent,
      createdAt: Date.now(),
      lastActive: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    };
    this.store.sessions.push(session);
    this.persist();
    return session;
  }

  public validateSession(sessionId: string): boolean {
    const session = this.store.sessions.find((s) => s.sessionId === sessionId);
    if (!session) return false;
    if (Date.now() > session.expiresAt) {
      this.revokeSession(sessionId);
      return false;
    }
    session.lastActive = Date.now();
    return true;
  }

  public revokeSession(sessionId: string): void {
    this.store.sessions = this.store.sessions.filter((s) => s.sessionId !== sessionId);
    this.persist();
  }

  public revokeAllSessions(): void {
    this.store.sessions = [];
    this.persist();
  }

  public getSessions(): AdminSession[] {
    return this.store.sessions;
  }

  // --- Audit Logs ---
  public addAuditLog(action: string, adminId: string, ip: string, details: string) {
    const log: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      action,
      adminId,
      ip,
      details,
      timestamp: Date.now(),
    };
    this.store.auditLogs.unshift(log);
    if (this.store.auditLogs.length > 200) {
      this.store.auditLogs = this.store.auditLogs.slice(0, 200);
    }
    this.persist();
  }

  public getAuditLogs(): AuditLog[] {
    return this.store.auditLogs;
  }
}

export const db = new Database();
