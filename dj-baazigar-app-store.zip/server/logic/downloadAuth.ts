import crypto from 'node:crypto';

export interface DownloadTokenPayload {
  appId: string;
  orderId: string;
  issuedAt: number;
  expiresAt: number;
}

/**
 * Creates a signed download token valid for a specified duration (default 30 minutes).
 */
export function createDownloadToken(
  appId: string,
  orderId: string,
  secretKey: string,
  validityMs: number = 30 * 60 * 1000
): string {
  const now = Date.now();
  const payload: DownloadTokenPayload = {
    appId,
    orderId,
    issuedAt: now,
    expiresAt: now + validityMs,
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', secretKey)
    .update(payloadBase64)
    .digest('base64url');

  return `${payloadBase64}.${signature}`;
}

/**
 * Verifies the download token signature and expiry, returning the payload if valid.
 */
export function verifyDownloadToken(
  token: string,
  secretKey: string,
  currentTime: number = Date.now()
): { valid: boolean; payload?: DownloadTokenPayload; error?: string } {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Token missing or invalid' };
  }

  const parts = token.split('.');
  if (parts.length !== 2) {
    return { valid: false, error: 'Malformed token structure' };
  }

  const [payloadBase64, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', secretKey)
    .update(payloadBase64)
    .digest('base64url');

  if (signature !== expectedSig) {
    return { valid: false, error: 'Invalid token signature' };
  }

  try {
    const payload: DownloadTokenPayload = JSON.parse(
      Buffer.from(payloadBase64, 'base64url').toString('utf-8')
    );

    if (currentTime > payload.expiresAt) {
      return { valid: false, error: 'Download token expired' };
    }

    return { valid: true, payload };
  } catch (err) {
    return { valid: false, error: 'Failed to decode token payload' };
  }
}
