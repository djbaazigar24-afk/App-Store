export interface PaymentRecord {
  orderId: string;
  appId: string;
  appName: string;
  amount: number;
  payableAmount: number;
  upiId: string;
  status: 'CREATED' | 'PENDING' | 'SUCCESS' | 'EXPIRED' | 'FAILED';
  transactionId?: string;
  utr?: string;
  senderName?: string;
  createdAt: number;
  paidAt?: number;
  expiresAt: number;
}

/**
 * Validates whether an incoming UTR has already been processed in any successful payment
 * to prevent duplicate payment / replay attacks.
 */
export function isDuplicateUtr(
  utr: string | undefined | null,
  currentOrderId: string,
  existingPayments: PaymentRecord[]
): boolean {
  if (!utr || !utr.trim()) return false;
  const cleanUtr = utr.trim().toLowerCase();
  
  return existingPayments.some(
    (p) =>
      p.orderId !== currentOrderId &&
      p.status === 'SUCCESS' &&
      p.utr &&
      p.utr.trim().toLowerCase() === cleanUtr
  );
}

/**
 * Validates that the paid amount matches or satisfies the required payable amount.
 */
export function validatePaymentAmount(
  paidAmount: number,
  expectedPayableAmount: number,
  tolerance = 0.01
): boolean {
  if (typeof paidAmount !== 'number' || isNaN(paidAmount) || paidAmount <= 0) {
    return false;
  }
  return Math.abs(paidAmount - expectedPayableAmount) <= tolerance;
}

/**
 * Formats UPI intent string for seamless app-to-app UPI payment in India.
 */
export function generateUpiIntentUrl(params: {
  upiId: string;
  payeeName: string;
  amount: number;
  transactionNote: string;
  orderId: string;
}): string {
  const note = encodeURIComponent(params.transactionNote || `DJ Baazigar ${params.orderId}`);
  const pn = encodeURIComponent(params.payeeName || 'DJ Baazigar');
  const pa = encodeURIComponent(params.upiId);
  const am = params.amount.toFixed(2);
  const tr = encodeURIComponent(params.orderId);
  
  return `upi://pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${note}&tr=${tr}`;
}
