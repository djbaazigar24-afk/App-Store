import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isDuplicateUtr,
  validatePaymentAmount,
  generateUpiIntentUrl,
  PaymentRecord,
} from './paymentRules';
import { createDownloadToken, verifyDownloadToken } from './downloadAuth';

test('isDuplicateUtr detects used UTR correctly', () => {
  const existingPayments: PaymentRecord[] = [
    {
      orderId: 'ord_1',
      appId: 'app_1',
      appName: 'VIP Modz',
      amount: 99,
      payableAmount: 99,
      upiId: 'test@upi',
      status: 'SUCCESS',
      utr: '123456789012',
      createdAt: Date.now() - 10000,
      expiresAt: Date.now() + 10000,
    },
    {
      orderId: 'ord_2',
      appId: 'app_2',
      appName: 'Free Tool',
      amount: 49,
      payableAmount: 49,
      upiId: 'test@upi',
      status: 'FAILED',
      utr: '987654321098',
      createdAt: Date.now() - 5000,
      expiresAt: Date.now() + 10000,
    },
  ];

  // Identical UTR from different order should be detected as duplicate
  assert.equal(
    isDuplicateUtr('123456789012', 'ord_3', existingPayments),
    true
  );

  // Same order re-checking should NOT be flagged as duplicate of another order
  assert.equal(
    isDuplicateUtr('123456789012', 'ord_1', existingPayments),
    false
  );

  // UTR from failed payment is allowed to be claimed or retried
  assert.equal(
    isDuplicateUtr('987654321098', 'ord_3', existingPayments),
    false
  );

  // Brand new UTR is not duplicate
  assert.equal(
    isDuplicateUtr('444555666777', 'ord_3', existingPayments),
    false
  );
});

test('validatePaymentAmount correctly validates amount with tolerance', () => {
  assert.equal(validatePaymentAmount(99, 99), true);
  assert.equal(validatePaymentAmount(99.004, 99), true);
  assert.equal(validatePaymentAmount(98.5, 99), false);
  assert.equal(validatePaymentAmount(0, 99), false);
  assert.equal(validatePaymentAmount(-10, 99), false);
});

test('generateUpiIntentUrl formats compliant UPI URI', () => {
  const uri = generateUpiIntentUrl({
    upiId: 'abhijit-dalui@fam',
    payeeName: 'DJ Baazigar',
    amount: 149,
    transactionNote: 'DJ Baazigar App Store',
    orderId: 'fg_TEST123',
  });

  assert.match(uri, /^upi:\/\/pay\?/);
  assert.match(uri, /pa=abhijit-dalui%40fam/);
  assert.match(uri, /am=149\.00/);
  assert.match(uri, /cu=INR/);
  assert.match(uri, /tr=fg_TEST123/);
});

test('createDownloadToken and verifyDownloadToken work end-to-end', () => {
  const secret = 'super-secret-key-12345';
  const token = createDownloadToken('app_vip_1', 'fg_ORDER_99', secret, 1000);

  // Valid token
  const result = verifyDownloadToken(token, secret);
  assert.equal(result.valid, true);
  assert.equal(result.payload?.appId, 'app_vip_1');
  assert.equal(result.payload?.orderId, 'fg_ORDER_99');

  // Tampered token fails
  const tampered = token.slice(0, -4) + 'abcd';
  const tamperedResult = verifyDownloadToken(tampered, secret);
  assert.equal(tamperedResult.valid, false);

  // Expired token fails
  const expiredToken = createDownloadToken('app_vip_1', 'fg_ORDER_99', secret, -100);
  const expiredResult = verifyDownloadToken(expiredToken, secret);
  assert.equal(expiredResult.valid, false);
  assert.match(expiredResult.error || '', /expired/i);
});

test('buildAndroidApkArchive creates authentic valid ZIP APK structure', async () => {
  const { buildAndroidApkArchive } = await import('./apkBuilder');
  const buffer = buildAndroidApkArchive('com.djbaazigar.test', '1.0.0', 'Test App');

  assert.ok(buffer.length > 200);
  // Magic bytes PK\x03\x04
  assert.equal(buffer[0], 0x50); // 'P'
  assert.equal(buffer[1], 0x4b); // 'K'
  assert.equal(buffer[2], 0x03);
  assert.equal(buffer[3], 0x04);

  // Check AndroidManifest.xml inclusion
  const str = buffer.toString('utf8');
  assert.ok(str.includes('AndroidManifest.xml'));
  assert.ok(str.includes('com.djbaazigar.test'));
});
