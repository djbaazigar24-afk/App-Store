import React, { useState } from 'react';
import {
  X,
  Download,
  Star,
  ShieldCheck,
  Smartphone,
  Calendar,
  HardDrive,
  CheckCircle2,
  Lock,
  Share2,
  Disc3,
} from 'lucide-react';
import { AppItem } from '../types';

interface AppDetailModalProps {
  app: AppItem | null;
  onClose: () => void;
  onInitiateDownloadOrBuy: (app: AppItem) => void;
}

export const AppDetailModal: React.FC<AppDetailModalProps> = ({
  app,
  onClose,
  onInitiateDownloadOrBuy,
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [selectedScreenshot, setSelectedScreenshot] = useState<string | null>(null);

  if (!app) return null;

  const isFree = app.price === 0;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div
        className="relative w-full max-w-3xl bg-[#0c071a] border border-purple-800/40 rounded-3xl overflow-hidden shadow-2xl shadow-purple-950/80 my-8 animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Banner & Close Button */}
        <div className="relative h-40 sm:h-52 bg-gradient-to-r from-purple-950 via-indigo-950 to-[#0b0517] overflow-hidden">
          {app.bannerUrl ? (
            <img
              src={app.bannerUrl}
              alt={app.name}
              className="w-full h-full object-cover opacity-40 mix-blend-screen"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-800/20 via-transparent to-transparent" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c071a] via-[#0c071a]/50 to-transparent" />

          {/* Close & Share Controls */}
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              onClick={handleShare}
              className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/70 text-purple-300 hover:text-white flex items-center justify-center border border-purple-700/30 transition-all cursor-pointer"
              title="Share App"
              aria-label="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/70 text-slate-300 hover:text-white flex items-center justify-center border border-purple-700/30 transition-all cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {copiedShare && (
            <div className="absolute top-14 right-4 bg-purple-600 text-white text-xs px-3 py-1 rounded-md shadow-lg animate-in fade-in">
              Link copied!
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="px-6 pb-8 pt-0 -mt-16 sm:-mt-20 relative z-10 space-y-6">
          {/* Header Info: Icon, Title, Price, Buy Button */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="flex items-end gap-4">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden bg-[#160b2e] border-2 border-purple-500/50 p-0.5 shadow-xl shrink-0">
                {app.iconUrl ? (
                  <img
                    src={app.iconUrl}
                    alt={app.name}
                    className="w-full h-full object-cover rounded-[14px]"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full rounded-[14px] bg-gradient-to-br from-purple-600 to-indigo-900 flex items-center justify-center">
                    <Disc3 className="w-10 h-10 text-white" />
                  </div>
                )}
              </div>

              <div>
                <span className="text-xs font-semibold text-purple-400 tracking-wider uppercase block">
                  {app.category}
                </span>
                <h2 className="text-xl sm:text-2xl font-bold text-white leading-tight">
                  {app.name}
                </h2>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                  <div className="flex items-center gap-1 text-yellow-400">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span className="font-semibold text-white">{app.rating.toFixed(1)}</span>
                  </div>
                  <span aria-hidden="true">·</span>
                  <span>{app.downloadsCount.toLocaleString()} Verified Downloads</span>
                </div>
              </div>
            </div>

            {/* Action CTA Box */}
            <div className="shrink-0 flex flex-col sm:items-end gap-1.5">
              <button
                onClick={() => onInitiateDownloadOrBuy(app)}
                className={`w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-xl transition-all cursor-pointer whitespace-nowrap active:scale-[0.98] ${
                  isFree
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40'
                    : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-900/50'
                }`}
              >
                {isFree ? (
                  <>
                    <Download className="w-4 h-4 text-emerald-200" />
                    <span>Download APK (Free)</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-purple-200" />
                    <span>Pay ₹{app.price} & Unlock APK</span>
                  </>
                )}
              </button>
              {!isFree && (
                <span className="text-[10px] text-purple-300 font-mono text-center sm:text-right flex items-center gap-1 justify-center sm:justify-end">
                  <Lock className="w-3 h-3 text-yellow-400" />
                  <span>Download strictly locked until verified payment</span>
                </span>
              )}
            </div>
          </div>

          {/* Technical Specs Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl bg-[#120a26] border border-purple-900/40 text-xs">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />
              <div>
                <span className="text-slate-400 block">Version</span>
                <span className="font-semibold text-white">v{app.version}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-purple-400 shrink-0" />
              <div>
                <span className="text-slate-400 block">Size</span>
                <span className="font-semibold text-white">{app.sizeMb} MB</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-purple-400 shrink-0" />
              <div>
                <span className="text-slate-400 block">Updated</span>
                <span className="font-semibold text-white">
                  {new Date(app.updatedAt).toLocaleDateString('en-IN', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="text-slate-400 block">Safety</span>
                <span className="font-semibold text-emerald-300">Clean & Verified</span>
              </div>
            </div>
          </div>

          {/* Screenshots Gallery */}
          {app.screenshots && app.screenshots.length > 0 && (
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3">
                Preview & Screenshots
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {app.screenshots.map((s, idx) => (
                  <div
                    key={idx}
                    onClick={() => setSelectedScreenshot(s)}
                    className="relative rounded-xl overflow-hidden aspect-video bg-[#180e30] border border-purple-900/40 hover:border-purple-500 cursor-pointer group"
                  >
                    <img
                      src={s}
                      alt={`${app.name} preview ${idx + 1}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-2">
              About This VIP Application
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
              {app.description}
            </p>
          </div>

          {/* Key Features List */}
          {app.features && app.features.length > 0 && (
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3">
                VIP Features & Unlocked Capabilities
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {app.features.map((feat, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#110924] border border-purple-900/30 text-xs text-slate-200"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Safe APK Guarantee */}
          <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-800/40 flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0" />
            <div className="text-xs text-slate-300">
              <span className="font-bold text-white block">Official DJ Baazigar Clean APK Seal</span>
              Scanned with Play Protect and VirusTotal. Guaranteed 100% free from malware, adware, or background crypto miners.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
