import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Smartphone,
  CreditCard,
  Sliders,
  Shield,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  Check,
  Search,
  Download,
  Eye,
  RefreshCw,
  X,
  Menu,
  ChevronRight,
  TrendingUp,
  Users,
  AlertTriangle,
  Lock,
  Save,
  CheckCircle2,
  Sparkles,
  Upload,
  Image,
  FileUp,
  Film,
  Loader2,
} from 'lucide-react';
import { AppItem, AnalyticsData, PaymentTransaction, WebsiteSettings, AuditLog, AdminSession } from '../../types';

interface AdminDashboardProps {
  token: string;
  onLogout: () => void;
  onClose: () => void;
  onUpdateStore?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  token,
  onLogout,
  onClose,
  onUpdateStore,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'apps' | 'payments' | 'customization' | 'security'>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Data states
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [apps, setApps] = useState<AppItem[]>([]);
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const [settings, setSettings] = useState<WebsiteSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [sessions, setSessions] = useState<AdminSession[]>([]);

  // Filtering states
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('ALL');
  const [paymentSearch, setPaymentSearch] = useState('');
  const [appSearch, setAppSearch] = useState('');

  // Editing App Modal
  const [editingApp, setEditingApp] = useState<Partial<AppItem> | null>(null);
  const [isNewAppModal, setIsNewAppModal] = useState(false);

  // Password Change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<{ text: string; success: boolean } | null>(null);

  // Notification Toast
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const [uploadingIcon, setUploadingIcon] = useState(false);
  const [uploadingApk, setUploadingApk] = useState(false);
  const [uploadingScreenshots, setUploadingScreenshots] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };

  // Upload Icon file from gallery/device
  const handleUploadIcon = async (file: File) => {
    setUploadingIcon(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const res = await fetch('/api/admin/upload-file', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            filename: file.name,
            fileBase64: base64,
            fileType: 'image',
          }),
        });
        const data = await res.json();
        if (data.status === 'success' && data.fileUrl) {
          setEditingApp((prev) => (prev ? { ...prev, iconUrl: data.fileUrl } : null));
          showToast('App icon uploaded successfully from your device!');
        } else {
          alert(data.error || 'Icon upload failed');
        }
        setUploadingIcon(false);
      };
      reader.readAsDataURL(file);
    } catch (e) {
      console.error(e);
      setUploadingIcon(false);
    }
  };

  // Upload Site Logo file from device
  const handleUploadSiteLogo = async (file: File) => {
    setUploadingLogo(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const res = await fetch('/api/admin/upload-file', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            filename: file.name,
            fileBase64: base64,
            fileType: 'image',
          }),
        });
        const data = await res.json();
        if (data.status === 'success' && data.fileUrl) {
          setSettings((prev) => (prev ? { ...prev, siteLogo: data.fileUrl } : null));
          showToast('Store logo uploaded successfully from your device!');
        } else {
          alert(data.error || 'Logo upload failed');
        }
        setUploadingLogo(false);
      };
      reader.readAsDataURL(file);
    } catch (e) {
      console.error(e);
      setUploadingLogo(false);
    }
  };

  // Upload APK file directly from device storage
  const handleUploadApk = async (file: File) => {
    setUploadingApk(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const res = await fetch('/api/admin/upload-file', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            filename: file.name,
            fileBase64: base64,
            fileType: 'apk',
          }),
        });
        const data = await res.json();
        if (data.status === 'success' && data.filename) {
          setEditingApp((prev) =>
            prev
              ? {
                  ...prev,
                  apkFileName: data.filename,
                  sizeMb: data.sizeMb || prev.sizeMb || 25,
                }
              : null
          );
          showToast(`APK "${file.name}" uploaded successfully (${data.sizeMb} MB)!`);
        } else {
          alert(data.error || 'APK upload failed');
        }
        setUploadingApk(false);
      };
      reader.readAsDataURL(file);
    } catch (e) {
      console.error(e);
      setUploadingApk(false);
    }
  };

  // Upload Screenshots from gallery
  const handleUploadScreenshot = async (files: FileList) => {
    setUploadingScreenshots(true);
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const base64 = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });

        const res = await fetch('/api/admin/upload-file', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            filename: file.name,
            fileBase64: base64,
            fileType: 'image',
          }),
        });
        const data = await res.json();
        if (data.status === 'success' && data.fileUrl) {
          setEditingApp((prev) =>
            prev
              ? {
                  ...prev,
                  screenshots: [...(prev.screenshots || []), data.fileUrl],
                }
              : null
          );
        }
      }
      showToast('Screenshots uploaded successfully from device!');
    } catch (e) {
      console.error(e);
    } finally {
      setUploadingScreenshots(false);
    }
  };

  // Fetch initial data
  const fetchData = async () => {
    try {
      const [analyticsRes, appsRes, paymentsRes, settingsRes, logsRes, sessionsRes] = await Promise.all([
        fetch('/api/admin/analytics', { headers: authHeaders }),
        fetch('/api/admin/apps', { headers: authHeaders }),
        fetch('/api/admin/payments', { headers: authHeaders }),
        fetch('/api/admin/settings', { headers: authHeaders }),
        fetch('/api/admin/audit-logs', { headers: authHeaders }),
        fetch('/api/admin/sessions', { headers: authHeaders }),
      ]);

      if (analyticsRes.ok) setAnalytics(await analyticsRes.json());
      if (appsRes.ok) setApps(await appsRes.json());
      if (paymentsRes.ok) setPayments(await paymentsRes.json());
      if (settingsRes.ok) setSettings(await settingsRes.json());
      if (logsRes.ok) setAuditLogs(await logsRes.json());
      if (sessionsRes.ok) setSessions(await sessionsRes.json());
    } catch (err) {
      console.error('Error fetching admin data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        showToast('Website settings saved & published successfully!');
        fetchData();
        onUpdateStore?.();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Save App (Create or Update)
  const handleSaveApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingApp) return;

    try {
      if (isNewAppModal) {
        const res = await fetch('/api/admin/apps', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify(editingApp),
        });
        if (res.ok) {
          showToast('New application published successfully!');
          setIsNewAppModal(false);
          setEditingApp(null);
          fetchData();
          onUpdateStore?.();
        }
      } else if (editingApp.id) {
        const res = await fetch(`/api/admin/apps/${editingApp.id}`, {
          method: 'PUT',
          headers: authHeaders,
          body: JSON.stringify(editingApp),
        });
        if (res.ok) {
          showToast('Application updated successfully!');
          setEditingApp(null);
          fetchData();
          onUpdateStore?.();
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Delete App
  const handleDeleteApp = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"?`)) return;

    try {
      const res = await fetch(`/api/admin/apps/${id}`, {
        method: 'DELETE',
        headers: authHeaders,
      });
      if (res.ok) {
        showToast('Application removed');
        fetchData();
        onUpdateStore?.();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Verify payment manually with gateway
  const handleVerifyPayment = async (orderId: string) => {
    try {
      const res = await fetch('/api/payment/verify-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: orderId }),
      });
      const data = await res.json();
      if (res.ok && data.status === 'success') {
        showToast(`Order ${orderId} verified & authorized!`);
        fetchData();
      } else {
        alert(data.message || 'Payment verification returned negative from gateway.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Export CSV
  const handleExportCsv = async () => {
    try {
      const res = await fetch('/api/admin/payments/export', {
        method: 'POST',
        headers: authHeaders,
      });
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `DJ_Baazigar_Payments_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      console.error('CSV export failed:', e);
    }
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg(null);
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        setPasswordMsg({ text: 'Master password changed successfully!', success: true });
        setCurrentPassword('');
        setNewPassword('');
        if (data.newToken) {
          localStorage.setItem('dj_admin_token', data.newToken);
        }
      } else {
        setPasswordMsg({ text: data.error || 'Password update failed', success: false });
      }
    } catch (e) {
      setPasswordMsg({ text: 'Network error', success: false });
    }
  };

  // Revoke Sessions
  const handleRevokeSessions = async () => {
    if (!confirm('Revoke all other active admin sessions?')) return;
    try {
      await fetch('/api/admin/revoke-sessions', {
        method: 'POST',
        headers: authHeaders,
      });
      showToast('All other sessions revoked');
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  // Filtered payments
  const filteredPayments = payments.filter((p) => {
    const matchesStatus = paymentStatusFilter === 'ALL' || p.status === paymentStatusFilter;
    const matchesSearch =
      paymentSearch === '' ||
      p.orderId.toLowerCase().includes(paymentSearch.toLowerCase()) ||
      p.appName.toLowerCase().includes(paymentSearch.toLowerCase()) ||
      (p.utr && p.utr.toLowerCase().includes(paymentSearch.toLowerCase())) ||
      (p.senderName && p.senderName.toLowerCase().includes(paymentSearch.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  // Filtered apps
  const filteredApps = apps.filter(
    (a) =>
      appSearch === '' ||
      a.name.toLowerCase().includes(appSearch.toLowerCase()) ||
      a.category.toLowerCase().includes(appSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#070410] text-slate-100 flex flex-col">
      {/* Top Mobile Bar */}
      <div className="h-16 px-4 bg-[#0d071c] border-b border-purple-900/40 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl bg-purple-950/60 text-purple-300 hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-red-600 via-purple-600 to-indigo-600 flex items-center justify-center font-bold text-xs text-white">
              DJ
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight block">SUPER ADMIN</span>
              <span className="text-[10px] text-purple-400 font-mono block">DJ Baazigar Console</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            className="p-2 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 hover:text-white transition-colors cursor-pointer"
            title="Refresh Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-900/80 text-xs font-semibold text-purple-200 hover:text-white border border-purple-700/30 transition-all cursor-pointer"
          >
            Exit to Store
          </button>
          <button
            onClick={onLogout}
            className="p-2 rounded-xl bg-red-950/50 hover:bg-red-900/80 text-red-300 hover:text-white transition-colors cursor-pointer"
            title="Secure Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <aside
          className={`${
            mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
          } md:translate-x-0 fixed md:relative z-40 w-64 h-[calc(100%-4rem)] md:h-full bg-[#0a0516] border-r border-purple-900/30 flex flex-col justify-between transition-transform duration-300 shrink-0`}
        >
          <div className="p-4 space-y-1.5">
            <button
              onClick={() => {
                setActiveTab('overview');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Overview & Analytics</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('apps');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'apps'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>App Management</span>
              <span className="ml-auto text-[10px] bg-purple-950 px-2 py-0.5 rounded font-mono text-purple-300">
                {apps.length}
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('payments');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'payments'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>FamGateway Payments</span>
              <span className="ml-auto text-[10px] bg-purple-950 px-2 py-0.5 rounded font-mono text-purple-300">
                {payments.length}
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('customization');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'customization'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>Website Customization</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('security');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'security'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Security & Audit Logs</span>
            </button>
          </div>

          {/* Quick System Badge */}
          <div className="p-4 border-t border-purple-900/30">
            <div className="p-3 rounded-xl bg-[#120824] border border-purple-900/40 text-[11px] space-y-1">
              <div className="flex items-center justify-between text-slate-400">
                <span>FamGateway:</span>
                <span className="text-emerald-400 font-semibold">Active</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Merchant UPI:</span>
                <span className="text-purple-300 font-mono truncate max-w-[110px]">abhijit-dalui@fam</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Content Pane */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#070410]">
          {/* Toast Alert */}
          {toast && (
            <div className="fixed bottom-6 right-6 z-50 bg-purple-600 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-2xl shadow-purple-950 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span>{toast}</span>
            </div>
          )}

          {/* TAB 1: OVERVIEW & ANALYTICS */}
          {activeTab === 'overview' && analytics && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">Dashboard Analytics</h2>
                <p className="text-xs text-slate-400">
                  Live store telemetry, financial performance, and download statistics.
                </p>
              </div>

              {/* KPI Cards Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <div className="p-4 rounded-2xl bg-[#0f0822] border border-purple-900/40">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-semibold">Total Revenue</span>
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                    ₹{analytics.totalRevenue.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-emerald-400 mt-1">100% UPI Direct</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#0f0822] border border-purple-900/40">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-semibold">Total Downloads</span>
                    <Download className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                    {analytics.totalDownloads.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-purple-300 mt-1">Across all applications</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#0f0822] border border-purple-900/40">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-semibold">Successful Orders</span>
                    <Check className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
                    {analytics.successfulPaymentsCount}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">Verified transactions</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#0f0822] border border-purple-900/40">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-semibold">Store Visitors</span>
                    <Users className="w-4 h-4 text-blue-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                    {analytics.totalVisitors.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-blue-400 mt-1">Real page interactions</div>
                </div>
              </div>

              {/* Status Breakdown & Category Split */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="p-5 rounded-2xl bg-[#0f0822] border border-purple-900/40 space-y-3">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Payment Gateway Status Funnel
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#150c2e]">
                      <span className="text-emerald-400 font-semibold">SUCCESS (Paid)</span>
                      <span className="font-mono text-white font-bold">{analytics.successfulPaymentsCount}</span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#150c2e]">
                      <span className="text-yellow-400 font-semibold">PENDING (Awaiting Scan)</span>
                      <span className="font-mono text-white font-bold">{analytics.pendingPaymentsCount}</span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#150c2e]">
                      <span className="text-slate-400 font-semibold">EXPIRED / TIMEOUT</span>
                      <span className="font-mono text-white font-bold">{analytics.expiredPaymentsCount}</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0f0822] border border-purple-900/40 space-y-3">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Application Inventory
                  </h3>
                  <div className="space-y-2 text-xs">
                    {Object.entries(analytics.categoryCounts).map(([cat, count]) => (
                      <div key={cat} className="flex items-center justify-between p-2.5 rounded-xl bg-[#150c2e]">
                        <span className="text-slate-300">{cat}</span>
                        <span className="font-mono text-purple-300 font-bold">{count} Apps</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recent Transactions Table */}
              <div className="p-5 rounded-2xl bg-[#0f0822] border border-purple-900/40 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Recent UPI Transactions
                  </h3>
                  <button
                    onClick={() => setActiveTab('payments')}
                    className="text-xs text-purple-400 hover:underline cursor-pointer"
                  >
                    View All &rarr;
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-purple-900/40 text-slate-400">
                        <th className="py-2.5 px-3">Order ID</th>
                        <th className="py-2.5 px-3">Application</th>
                        <th className="py-2.5 px-3">Amount</th>
                        <th className="py-2.5 px-3">UTR</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Time</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-purple-900/20">
                      {analytics.recentTransactions.slice(0, 6).map((tx) => (
                        <tr key={tx.orderId} className="hover:bg-purple-950/30">
                          <td className="py-2.5 px-3 font-mono text-purple-300">{tx.orderId}</td>
                          <td className="py-2.5 px-3 text-white font-medium">{tx.appName}</td>
                          <td className="py-2.5 px-3 font-mono font-bold text-white">₹{tx.payableAmount}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-400">{tx.utr || '—'}</td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                tx.status === 'SUCCESS'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : tx.status === 'PENDING'
                                  ? 'bg-yellow-950 text-yellow-400 border border-yellow-800'
                                  : 'bg-slate-900 text-slate-400 border border-slate-800'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-400">
                            {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: APPLICATION MANAGEMENT */}
          {activeTab === 'apps' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-white">Application Management</h2>
                  <p className="text-xs text-slate-400">
                    Add, edit, upload APKs, set pricing, or publish/unpublish apps.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setEditingApp({
                      name: '',
                      category: 'DJ & Music Modz',
                      version: '1.0.0',
                      sizeMb: 30,
                      price: 99,
                      rating: 4.8,
                      downloadsCount: 0,
                      iconUrl: '/src/assets/images/app_dj_baazigar_vip_1793910718594.jpg',
                      bannerUrl: '/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg',
                      shortDesc: '',
                      description: '',
                      features: ['VIP Unlocked', 'Zero Latency'],
                      published: true,
                      downloadsEnabled: true,
                      isTrending: false,
                      isPopular: false,
                    });
                    setIsNewAppModal(true);
                  }}
                  className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-lg shadow-purple-600/30 cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Application</span>
                </button>
              </div>

              {/* Search input */}
              <div className="relative max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={appSearch}
                  onChange={(e) => setAppSearch(e.target.value)}
                  placeholder="Filter applications..."
                  className="w-full bg-[#120a26] border border-purple-900/40 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none"
                />
              </div>

              {/* Apps List */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredApps.map((app) => (
                  <div
                    key={app.id}
                    className="p-4 rounded-2xl bg-[#0e0720] border border-purple-900/40 flex flex-col justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-purple-950/60 border border-purple-700/40 p-0.5 shrink-0">
                          <img
                            src={app.iconUrl}
                            alt={app.name}
                            className="w-full h-full object-cover rounded-[10px]"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              app.price === 0
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-purple-950 text-purple-300 border border-purple-800 font-mono'
                            }`}
                          >
                            {app.price === 0 ? 'FREE' : `₹${app.price}`}
                          </span>
                          <span
                            className={`text-[10px] ${
                              app.published ? 'text-emerald-400' : 'text-slate-500'
                            }`}
                          >
                            {app.published ? '● Live' : '○ Draft'}
                          </span>
                        </div>
                      </div>

                      <h4 className="text-sm font-bold text-white line-clamp-1">{app.name}</h4>
                      <p className="text-xs text-slate-400 mb-2">
                        {app.category} · v{app.version} · {app.sizeMb}MB
                      </p>
                      <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                        {app.shortDesc || app.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-purple-900/30 flex items-center justify-between gap-2">
                      <span className="text-[11px] text-slate-400 font-mono">
                        {app.downloadsCount.toLocaleString()} DLs
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setEditingApp({ ...app });
                            setIsNewAppModal(false);
                          }}
                          className="p-1.5 rounded-lg bg-purple-900/30 hover:bg-purple-800 text-purple-300 hover:text-white cursor-pointer"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteApp(app.id, app.name)}
                          className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900 text-red-400 hover:text-white cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PAYMENTS MANAGEMENT */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-white">FamGateway Transactions</h2>
                  <p className="text-xs text-slate-400">
                    Audit UPI payments, verify UTR numbers, and export reconciliation reports.
                  </p>
                </div>
                <button
                  onClick={handleExportCsv}
                  className="px-4 py-2.5 bg-[#170e2e] hover:bg-[#221444] text-purple-200 border border-purple-700/40 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <Download className="w-4 h-4 text-purple-400" />
                  <span>Export CSV Report</span>
                </button>
              </div>

              {/* Filter and Search Bar */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1 bg-[#120a26] p-1 rounded-xl border border-purple-900/40 text-xs font-semibold">
                  {['ALL', 'SUCCESS', 'PENDING', 'EXPIRED'].map((st) => (
                    <button
                      key={st}
                      onClick={() => setPaymentStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                        paymentStatusFilter === st
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>

                <div className="relative flex-1 min-w-[200px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={paymentSearch}
                    onChange={(e) => setPaymentSearch(e.target.value)}
                    placeholder="Search by Order ID, UTR, App..."
                    className="w-full bg-[#120a26] border border-purple-900/40 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Transactions Table */}
              <div className="rounded-2xl bg-[#0e0720] border border-purple-900/40 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-purple-900/40 bg-[#12092a] text-slate-400">
                        <th className="py-3 px-4">Order ID</th>
                        <th className="py-3 px-4">App Purchased</th>
                        <th className="py-3 px-4">Payable</th>
                        <th className="py-3 px-4">UTR / Ref</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4">Date & Time</th>
                        <th className="py-3 px-4 text-right">Gateway Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-purple-900/20">
                      {filteredPayments.map((p) => (
                        <tr key={p.orderId} className="hover:bg-purple-950/30">
                          <td className="py-3 px-4 font-mono text-purple-300 font-semibold">{p.orderId}</td>
                          <td className="py-3 px-4 text-white font-medium">{p.appName}</td>
                          <td className="py-3 px-4 font-mono font-bold text-white">₹{p.payableAmount.toFixed(2)}</td>
                          <td className="py-3 px-4 font-mono text-emerald-400">{p.utr || '—'}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                p.status === 'SUCCESS'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : p.status === 'PENDING'
                                  ? 'bg-yellow-950 text-yellow-400 border border-yellow-800'
                                  : 'bg-slate-900 text-slate-400 border border-slate-800'
                              }`}
                            >
                              {p.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400">
                            {new Date(p.createdAt).toLocaleDateString('en-IN', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {p.status !== 'SUCCESS' ? (
                              <button
                                onClick={() => handleVerifyPayment(p.orderId)}
                                className="px-2.5 py-1 bg-purple-900/40 hover:bg-purple-700 text-purple-200 hover:text-white rounded-lg text-[11px] font-semibold cursor-pointer whitespace-nowrap"
                              >
                                Check Gateway
                              </button>
                            ) : (
                              <span className="text-emerald-400 text-[11px] font-semibold flex items-center justify-end gap-1">
                                <Check className="w-3.5 h-3.5" /> Verified
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                      {filteredPayments.length === 0 && (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-slate-500">
                            No payment transactions match your query.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: WEBSITE CUSTOMIZATION */}
          {activeTab === 'customization' && settings && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">Website Customization</h2>
                <p className="text-xs text-slate-400">
                  Update store branding, headlines, announcement ticker, and contact channels.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    General Brand Identity
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Store Name</label>
                      <input
                        type="text"
                        value={settings.siteName}
                        onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Site Title Tag</label>
                      <input
                        type="text"
                        value={settings.siteTitle}
                        onChange={(e) => setSettings({ ...settings, siteTitle: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Store Description</label>
                    <textarea
                      rows={2}
                      value={settings.siteDescription}
                      onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  {/* Store Logo Uploader */}
                  <div className="pt-2 border-t border-purple-900/30">
                    <label className="block text-xs font-semibold text-slate-300 mb-2">
                      Store Logo / Brand Icon (Upload from Phone Gallery / Device)
                    </label>
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-2xl overflow-hidden bg-[#180d33] border-2 border-purple-600/50 p-1 shrink-0 flex items-center justify-center">
                        {settings.siteLogo ? (
                          <img
                            src={settings.siteLogo}
                            alt="Store Logo"
                            className="w-full h-full object-cover rounded-xl"
                          />
                        ) : (
                          <Sparkles className="w-6 h-6 text-purple-400" />
                        )}
                      </div>

                      <div className="flex-1 space-y-2">
                        <label className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-xl cursor-pointer shadow-md transition-all">
                          <Upload className="w-3.5 h-3.5" />
                          <span>{uploadingLogo ? 'Uploading Logo...' : 'Upload Logo from Device'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              if (e.target.files?.[0]) {
                                handleUploadSiteLogo(e.target.files[0]);
                              }
                            }}
                          />
                        </label>
                        <input
                          type="text"
                          value={settings.siteLogo || ''}
                          onChange={(e) => setSettings({ ...settings, siteLogo: e.target.value })}
                          placeholder="Or paste image URL (e.g. https://...)"
                          className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2 text-xs text-white"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Announcement Banner
                  </h3>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Ticker Message</label>
                    <input
                      type="text"
                      value={settings.announcementBanner}
                      onChange={(e) => setSettings({ ...settings, announcementBanner: e.target.value })}
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="announcementEnabled"
                      checked={settings.announcementEnabled}
                      onChange={(e) => setSettings({ ...settings, announcementEnabled: e.target.checked })}
                      className="rounded accent-purple-600"
                    />
                    <label htmlFor="announcementEnabled" className="text-xs text-slate-300 cursor-pointer">
                      Display announcement banner on top of the marketplace
                    </label>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Hero Section Headlines
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Hero Badge Kicker</label>
                      <input
                        type="text"
                        value={settings.heroBadge}
                        onChange={(e) => setSettings({ ...settings, heroBadge: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Primary Color Accent</label>
                      <input
                        type="text"
                        value={settings.primaryColor}
                        onChange={(e) => setSettings({ ...settings, primaryColor: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Hero Headline</label>
                    <input
                      type="text"
                      value={settings.heroHeadline}
                      onChange={(e) => setSettings({ ...settings, heroHeadline: e.target.value })}
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Hero Subtitle</label>
                    <textarea
                      rows={2}
                      value={settings.heroSubtitle}
                      onChange={(e) => setSettings({ ...settings, heroSubtitle: e.target.value })}
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Official Contact Channels
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Telegram Support</label>
                      <input
                        type="text"
                        value={settings.contactTelegram}
                        onChange={(e) => setSettings({ ...settings, contactTelegram: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">WhatsApp Channel</label>
                      <input
                        type="text"
                        value={settings.contactWhatsApp}
                        onChange={(e) => setSettings({ ...settings, contactWhatsApp: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Support Email</label>
                      <input
                        type="email"
                        value={settings.contactEmail}
                        onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
                        className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="submit"
                    className="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-purple-900/40 cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save & Publish Changes</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 5: SECURITY & AUDIT LOGS */}
          {activeTab === 'security' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">Security & Audit Operations</h2>
                <p className="text-xs text-slate-400">
                  Password management, active session revocation, and security audit logs.
                </p>
              </div>

              {/* Password Change Form */}
              <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Lock className="w-4 h-4 text-purple-400" />
                  <span>Change Super Admin Password</span>
                </h3>

                {passwordMsg && (
                  <div
                    className={`p-3 rounded-xl text-xs font-semibold ${
                      passwordMsg.success
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                        : 'bg-red-950/80 text-red-300 border border-red-800'
                    }`}
                  >
                    {passwordMsg.text}
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Current Password</label>
                    <input
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">New Password</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 5 characters"
                      className="w-full bg-[#150a2b] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs cursor-pointer"
                  >
                    Update Password
                  </button>
                </form>
              </div>

              {/* Active Sessions */}
              <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Active Administrative Sessions ({sessions.length})
                  </h3>
                  <button
                    onClick={handleRevokeSessions}
                    className="px-3 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-300 hover:text-white rounded-lg text-xs font-semibold border border-red-800/40 cursor-pointer"
                  >
                    Revoke All Sessions
                  </button>
                </div>

                <div className="space-y-2">
                  {sessions.map((s, idx) => (
                    <div
                      key={s.sessionId}
                      className="p-3 rounded-xl bg-[#140b2a] border border-purple-900/30 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-mono text-purple-300 font-semibold truncate max-w-xs">
                          IP: {s.ip} {idx === 0 && '(Current Session)'}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-sm">
                          {s.userAgent}
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded">
                        Active
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Audit Logs Table */}
              <div className="p-5 rounded-2xl bg-[#0e0720] border border-purple-900/40 space-y-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Security Audit Trail (Latest 20)
                </h3>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-purple-900/40 text-slate-400">
                        <th className="py-2.5 px-3">Action</th>
                        <th className="py-2.5 px-3">Operator</th>
                        <th className="py-2.5 px-3">IP Address</th>
                        <th className="py-2.5 px-3">Details</th>
                        <th className="py-2.5 px-3">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-purple-900/20">
                      {auditLogs.slice(0, 20).map((log) => (
                        <tr key={log.id} className="hover:bg-purple-950/30">
                          <td className="py-2.5 px-3 font-mono font-bold text-purple-300">{log.action}</td>
                          <td className="py-2.5 px-3 text-slate-300">{log.adminId}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-400">{log.ip}</td>
                          <td className="py-2.5 px-3 text-slate-300">{log.details}</td>
                          <td className="py-2.5 px-3 text-slate-400">
                            {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: ADD / EDIT APPLICATION */}
      {editingApp && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-2xl bg-[#0f0824] border border-purple-700/50 rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-8 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-purple-900/40 mb-4">
              <h3 className="text-lg font-bold text-white">
                {isNewAppModal ? 'Publish New VIP Application' : `Edit: ${editingApp.name}`}
              </h3>
              <button
                onClick={() => setEditingApp(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveApp} className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Application Name *</label>
                  <input
                    type="text"
                    value={editingApp.name || ''}
                    onChange={(e) => setEditingApp({ ...editingApp, name: e.target.value })}
                    className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category *</label>
                  <select
                    value={editingApp.category || 'DJ & Music Modz'}
                    onChange={(e) => setEditingApp({ ...editingApp, category: e.target.value })}
                    className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="DJ & Music Modz">DJ & Music Modz</option>
                    <option value="VIP Audio Tools">VIP Audio Tools</option>
                    <option value="Game Boosters">Game Boosters</option>
                    <option value="Utility Tools">Utility Tools</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Price (₹ INR, 0=Free)</label>
                  <input
                    type="number"
                    value={editingApp.price !== undefined ? editingApp.price : 99}
                    onChange={(e) => setEditingApp({ ...editingApp, price: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Version</label>
                  <input
                    type="text"
                    value={editingApp.version || '1.0.0'}
                    onChange={(e) => setEditingApp({ ...editingApp, version: e.target.value })}
                    className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Size (MB)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={editingApp.sizeMb !== undefined ? editingApp.sizeMb : 25}
                    onChange={(e) => setEditingApp({ ...editingApp, sizeMb: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              {/* 1. App Icon / Logo Upload Section */}
              <div className="p-3.5 rounded-2xl bg-[#140a2c] border border-purple-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Image className="w-3.5 h-3.5 text-purple-400" />
                    <span>App Icon / Logo (From Phone Gallery / Device)</span>
                  </label>
                  {uploadingIcon && (
                    <span className="text-[11px] text-purple-300 flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" /> Uploading photo...
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-4">
                  {/* Thumbnail Preview */}
                  <div className="w-16 h-16 rounded-2xl overflow-hidden bg-[#1e0f3d] border-2 border-purple-500/50 p-0.5 shrink-0 flex items-center justify-center">
                    {editingApp.iconUrl ? (
                      <img
                        src={editingApp.iconUrl}
                        alt="Icon Preview"
                        className="w-full h-full object-cover rounded-[14px]"
                      />
                    ) : (
                      <Image className="w-6 h-6 text-slate-500" />
                    )}
                  </div>

                  <div className="flex-1 space-y-2">
                    <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-xl cursor-pointer shadow-md transition-all">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Icon from Device / Gallery</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files?.[0]) {
                            handleUploadIcon(e.target.files[0]);
                          }
                        }}
                      />
                    </label>
                    <input
                      type="text"
                      value={editingApp.iconUrl || ''}
                      onChange={(e) => setEditingApp({ ...editingApp, iconUrl: e.target.value })}
                      placeholder="Or paste external image URL..."
                      className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Direct APK File Upload Section */}
              <div className="p-3.5 rounded-2xl bg-[#140a2c] border border-purple-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <FileUp className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Real APK File Upload (From Device Storage)</span>
                  </label>
                  {uploadingApk && (
                    <span className="text-[11px] text-emerald-300 flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" /> Uploading APK binary...
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold rounded-xl cursor-pointer shadow-md transition-all">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Select APK from Phone / PC</span>
                      <input
                        type="file"
                        accept=".apk,application/vnd.android.package-archive"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files?.[0]) {
                            handleUploadApk(e.target.files[0]);
                          }
                        }}
                      />
                    </label>

                    {editingApp.apkFileName && (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-xs font-mono">
                        <Check className="w-3.5 h-3.5" />
                        <span className="truncate max-w-[200px]">{editingApp.apkFileName}</span>
                        <span>({editingApp.sizeMb} MB)</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Or External Download URL (e.g. Google Drive / Telegram CDN link)
                    </label>
                    <input
                      type="text"
                      value={editingApp.apkDownloadUrl || ''}
                      onChange={(e) => setEditingApp({ ...editingApp, apkDownloadUrl: e.target.value })}
                      placeholder="https://..."
                      className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* 3. Screenshots Gallery Upload Section */}
              <div className="p-3.5 rounded-2xl bg-[#140a2c] border border-purple-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Film className="w-3.5 h-3.5 text-blue-400" />
                    <span>App Screenshots (From Gallery / Photos)</span>
                  </label>
                  {uploadingScreenshots && (
                    <span className="text-[11px] text-blue-300 flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" /> Uploading screenshots...
                    </span>
                  )}
                </div>

                {/* Screenshots Thumbnails */}
                {editingApp.screenshots && editingApp.screenshots.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {editingApp.screenshots.map((src, idx) => (
                      <div
                        key={idx}
                        className="relative rounded-xl overflow-hidden aspect-video bg-[#1e0f3d] border border-purple-700/40 group"
                      >
                        <img src={src} alt={`Screenshot ${idx + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => {
                            setEditingApp({
                              ...editingApp,
                              screenshots: editingApp.screenshots?.filter((_, i) => i !== idx),
                            });
                          }}
                          className="absolute top-1 right-1 p-1 rounded-full bg-red-600/80 hover:bg-red-600 text-white opacity-90 group-hover:opacity-100 transition-opacity"
                          title="Remove screenshot"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#201042] hover:bg-[#2b1659] text-purple-200 text-xs font-semibold rounded-xl cursor-pointer border border-purple-700/40 transition-all">
                  <Upload className="w-3.5 h-3.5 text-purple-400" />
                  <span>Add Screenshots from Photos / Device</span>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        handleUploadScreenshot(e.target.files);
                      }
                    }}
                  />
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Description</label>
                <textarea
                  rows={3}
                  value={editingApp.description || ''}
                  onChange={(e) => setEditingApp({ ...editingApp, description: e.target.value })}
                  className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Features (comma separated)
                </label>
                <input
                  type="text"
                  value={Array.isArray(editingApp.features) ? editingApp.features.join(', ') : ''}
                  onChange={(e) =>
                    setEditingApp({
                      ...editingApp,
                      features: e.target.value.split(',').map((f) => f.trim()).filter(Boolean),
                    })
                  }
                  placeholder="Feature 1, Feature 2, Feature 3"
                  className="w-full bg-[#180d33] border border-purple-900/50 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="flex flex-wrap gap-4 pt-2">
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingApp.published !== false}
                    onChange={(e) => setEditingApp({ ...editingApp, published: e.target.checked })}
                    className="accent-purple-600 rounded"
                  />
                  <span>Publish to Public Marketplace</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingApp.downloadsEnabled !== false}
                    onChange={(e) => setEditingApp({ ...editingApp, downloadsEnabled: e.target.checked })}
                    className="accent-purple-600 rounded"
                  />
                  <span>Enable Downloads</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(editingApp.isTrending)}
                    onChange={(e) => setEditingApp({ ...editingApp, isTrending: e.target.checked })}
                    className="accent-purple-600 rounded"
                  />
                  <span>Mark as Trending</span>
                </label>
              </div>

              <div className="pt-4 border-t border-purple-900/40 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingApp(null)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-purple-600/30 cursor-pointer"
                >
                  Save Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
