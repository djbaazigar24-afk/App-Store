import React, { useState } from 'react';
import { Zap, X } from 'lucide-react';

interface AnnouncementBarProps {
  text: string;
  enabled: boolean;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({ text, enabled }) => {
  const [dismissed, setDismissed] = useState(false);

  if (!enabled || !text || dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-purple-950/90 border-b border-purple-800/40 text-purple-100 text-xs sm:text-sm py-2 px-4 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-hidden mx-auto">
          <Zap className="w-4 h-4 text-yellow-400 shrink-0 animate-bounce" />
          <span className="font-medium tracking-wide truncate">{text}</span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-purple-300 hover:text-white p-1 rounded-md transition-colors cursor-pointer shrink-0"
          aria-label="Dismiss announcement"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
