import React from 'react';
import { ShieldCheck, Download, Smartphone, Zap, Flame, Headphones } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface HeroSectionProps {
  settings: WebsiteSettings;
  onExploreClick: () => void;
  onTrendingClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  settings,
  onExploreClick,
  onTrendingClick,
}) => {
  return (
    <section id="hero" className="relative pt-6 pb-12 sm:pt-10 sm:pb-16 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-purple-900/20 via-indigo-900/10 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Headlines & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Subtle editorial kicker */}
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-purple-400 bg-purple-950/60 border border-purple-800/50 rounded-full px-3.5 py-1">
              <Headphones className="w-3.5 h-3.5 text-purple-300" />
              <span>{settings.heroBadge || 'OFFICIAL DJ BAAZIGAR STORE'}</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
              {settings.heroHeadline || 'NEXT-GEN VIP ANDROID MODZ & AUDIO SUITES'}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {settings.heroSubtitle ||
                'Download high-performance DJ mixers, VIP gaming modz, and exclusive audio tools. 100% Virus-Free & Instant UPI Access.'}
            </p>

            {/* CTA Group */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onExploreClick}
                className="px-6 py-3.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm sm:text-base rounded-xl shadow-xl shadow-purple-600/30 hover:shadow-purple-500/50 transition-all flex items-center gap-2.5 cursor-pointer whitespace-nowrap active:scale-[0.98]"
              >
                <Download className="w-4 h-4 text-purple-200" />
                <span>Browse VIP Modz</span>
              </button>

              <button
                onClick={onTrendingClick}
                className="px-6 py-3.5 bg-[#170e2e]/90 hover:bg-[#201440] text-purple-200 hover:text-white font-semibold text-sm sm:text-base rounded-xl border border-purple-700/40 hover:border-purple-500/60 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-[0.98]"
              >
                <Flame className="w-4 h-4 text-orange-400" />
                <span>Trending Hits</span>
              </button>
            </div>

            {/* Micro Trust Indicators */}
            <div className="pt-2 text-xs text-slate-400 flex flex-wrap items-center justify-center lg:justify-start gap-3">
              <span>⚡ Instant UPI Payment</span>
              <span aria-hidden="true">·</span>
              <span>🛡️ No Registration Required</span>
              <span aria-hidden="true">·</span>
              <span>📱 Android Chrome Ready</span>
            </div>
          </div>

          {/* Right Column: Visual Hero Banner Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden glass-panel p-2 shadow-2xl shadow-purple-950/60 border border-purple-500/20 group">
              <div className="relative rounded-xl overflow-hidden aspect-[16/10] bg-[#120a22]">
                <img
                  src="/src/assets/images/dj_baazigar_hero_banner_1793910718956.jpg"
                  alt="DJ Baazigar Audio Station"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                {/* Live Badge Overlay */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs font-semibold tracking-wide">
                      DJ Baazigar Certified Builds
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-purple-300 bg-purple-950/80 px-2 py-0.5 rounded border border-purple-800/40">
                    v4.8 VIP
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Item Feature / Trust Metric Strip */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-2xl bg-[#0e081e]/80 border border-purple-900/30">
          <div className="flex items-center gap-3 p-2">
            <div className="w-10 h-10 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">100% Virus Free</div>
              <div className="text-xs text-slate-400">Google Play Protect Tested</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2">
            <div className="w-10 h-10 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">Direct APK File</div>
              <div className="text-xs text-slate-400">High-speed CDN download</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2">
            <div className="w-10 h-10 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">FamGateway UPI</div>
              <div className="text-xs text-slate-400">Dynamic QR & Intent</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2">
            <div className="w-10 h-10 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5 text-pink-400" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">VIP Unlocked</div>
              <div className="text-xs text-slate-400">Exclusive DJ Baazigar Sound</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
