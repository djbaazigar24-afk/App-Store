import React from 'react';
import { X, ShieldCheck, FileText, Info } from 'lucide-react';

interface InfoModalsProps {
  type: 'about' | 'privacy' | 'terms' | null;
  onClose: () => void;
  siteName: string;
}

export const InfoModals: React.FC<InfoModalsProps> = ({ type, onClose, siteName }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div
        className="relative w-full max-w-2xl bg-[#0e0720] border border-purple-800/50 rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-8 my-8 text-xs text-slate-300 space-y-4"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-purple-950/60 hover:bg-purple-900/80 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {type === 'about' && (
          <>
            <div className="flex items-center gap-3 text-purple-400 mb-2">
              <Info className="w-6 h-6" />
              <h3 className="text-xl font-bold text-white">About {siteName}</h3>
            </div>
            <p className="leading-relaxed">
              <strong>{siteName}</strong> is the definitive destination for premium Android audio modification tools, live stage DJ soundboards, 8D audio equalizers, and performance boosters.
            </p>
            <p className="leading-relaxed">
              Curated and perfected for real stage performers, sound technicians, and mobile gamers across India. All applications published on our store undergo stringent integrity validation, virus scans, and compatibility checks across modern Android versions (Android 8.0 up to Android 15).
            </p>
            <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40 text-purple-200">
              <span className="font-bold text-white block mb-1">Zero Registration Guarantee</span>
              We firmly believe in frictionless access. Visitors can browse, preview, and download free tools or purchase VIP modz instantly via UPI without having to create customer accounts or surrender personal information.
            </div>
          </>
        )}

        {type === 'privacy' && (
          <>
            <div className="flex items-center gap-3 text-purple-400 mb-2">
              <ShieldCheck className="w-6 h-6" />
              <h3 className="text-xl font-bold text-white">Privacy Policy</h3>
            </div>
            <p className="leading-relaxed">
              Your privacy is of paramount importance to us. This Privacy Policy details how {siteName} handles information:
            </p>
            <div className="space-y-2">
              <h4 className="font-bold text-white">1. No Customer Accounts Required</h4>
              <p>
                We do not require users to create an account, register usernames, or store passwords. You can browse all apps freely.
              </p>

              <h4 className="font-bold text-white">2. Payment Data</h4>
              <p>
                All financial transactions are conducted directly through <strong>FamGateway</strong> via secure UPI protocols. We never store bank account numbers, debit/credit card credentials, or UPI PINs. FamGateway processes UPI payments and provides an authenticated server confirmation.
              </p>

              <h4 className="font-bold text-white">3. Download Tokens</h4>
              <p>
                Upon payment confirmation, a temporary cryptographically signed token is issued strictly to authorize the specific APK download for your order session.
              </p>
            </div>
          </>
        )}

        {type === 'terms' && (
          <>
            <div className="flex items-center gap-3 text-purple-400 mb-2">
              <FileText className="w-6 h-6" />
              <h3 className="text-xl font-bold text-white">Terms and Conditions</h3>
            </div>
            <div className="space-y-2 leading-relaxed">
              <h4 className="font-bold text-white">1. Software License</h4>
              <p>
                Applications purchased or downloaded from {siteName} are provided for personal, non-commercial use on personal Android devices.
              </p>

              <h4 className="font-bold text-white">2. Automatic Delivery & Refunds</h4>
              <p>
                Upon verified successful payment through FamGateway UPI, access to the corresponding APK file is unlocked immediately. In case of transaction issues or network dropouts, transaction IDs and UTR numbers can be verified via our support channels.
              </p>

              <h4 className="font-bold text-white">3. Android Compatibility</h4>
              <p>
                Users are responsible for ensuring that their devices support APK installation from unknown sources as permitted under Android operating system settings.
              </p>
            </div>
          </>
        )}

        <div className="pt-4 border-t border-purple-900/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
