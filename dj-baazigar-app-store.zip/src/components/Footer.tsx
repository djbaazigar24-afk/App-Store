import React from 'react';
import { Disc3, Send, MessageSquare, Mail, Phone, ShieldCheck, Heart } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface FooterProps {
  settings: WebsiteSettings;
  onOpenModal: (type: 'about' | 'privacy' | 'terms') => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onOpenModal }) => {
  return (
    <footer className="bg-[#05030b] border-t border-purple-950/80 pt-16 pb-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand Info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center p-0.5">
                <div className="w-full h-full bg-[#090514] rounded-[6px] flex items-center justify-center">
                  <Disc3 className="w-4 h-4 text-purple-400" />
                </div>
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                {settings.siteName || 'DJ BAAZIGAR'}
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              India's premier high-energy audio workstation & VIP mod marketplace. Engineered for professional sound artists, stage DJs, and power Android users.
            </p>
            <div className="flex items-center gap-2 text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Certified 100% Virus-Free APKs</span>
            </div>
          </div>

          {/* Col 2: Fast Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Store Sections</h4>
            <ul className="space-y-2">
              <li>
                <a href="#apps-catalog" className="hover:text-purple-400 transition-colors">
                  All Applications
                </a>
              </li>
              <li>
                <a href="#trending" className="hover:text-purple-400 transition-colors">
                  Trending Releases
                </a>
              </li>
              <li>
                <a href="#categories" className="hover:text-purple-400 transition-colors">
                  Categories & Sound Kits
                </a>
              </li>
              <li>
                <button
                  onClick={() => onOpenModal('about')}
                  className="hover:text-purple-400 transition-colors cursor-pointer text-left"
                >
                  About DJ Baazigar
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Legal & Security */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Legal & Compliance</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onOpenModal('privacy')}
                  className="hover:text-purple-400 transition-colors cursor-pointer text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenModal('terms')}
                  className="hover:text-purple-400 transition-colors cursor-pointer text-left"
                >
                  Terms and Conditions
                </button>
              </li>
              <li>
                <span className="text-slate-500">FamGateway Payment Security</span>
              </li>
              <li>
                <span className="text-slate-500">No Customer Registration Policy</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Contact */}
          <div id="contact" className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Contact & Support</h4>
            <ul className="space-y-2">
              {settings.contactTelegram && (
                <li className="flex items-center gap-2">
                  <Send className="w-3.5 h-3.5 text-blue-400" />
                  <a
                    href={`https://t.me/${settings.contactTelegram.replace('@', '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white"
                  >
                    Telegram: {settings.contactTelegram}
                  </a>
                </li>
              )}
              {settings.contactWhatsApp && (
                <li className="flex items-center gap-2">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp: {settings.contactWhatsApp}</span>
                </li>
              )}
              {settings.contactEmail && (
                <li className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-purple-400" />
                  <a href={`mailto:${settings.contactEmail}`} className="hover:text-white">
                    {settings.contactEmail}
                  </a>
                </li>
              )}
              {settings.contactPhone && (
                <li className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>Helpline: {settings.contactPhone}</span>
                </li>
              )}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-purple-900/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            &copy; {new Date().getFullYear()} {settings.siteName || 'DJ BAAZIGAR'}. All rights reserved. Built for Android enthusiasts.
          </div>
          <div className="flex items-center gap-1">
            <span>Official FamGateway Integration</span>
            <span aria-hidden="true">·</span>
            <span>UPI Instant Verification</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
