import React, { useState } from 'react';
import { Download, Star, ShieldCheck, Flame, Disc3, Lock } from 'lucide-react';
import { AppItem } from '../types';

interface AppCardProps {
  app: AppItem;
  onSelect: (app: AppItem) => void;
  onQuickDownload: (app: AppItem) => void;
}

export const AppCard: React.FC<AppCardProps> = ({ app, onSelect, onQuickDownload }) => {
  const [imageError, setImageError] = useState(false);

  const isFree = app.price === 0;

  return (
    <div
      onClick={() => onSelect(app)}
      className="group relative flex flex-col justify-between rounded-2xl bg-[#0d071c] hover:bg-[#130b29] border border-purple-900/30 hover:border-purple-600/50 p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-900/20 cursor-pointer"
    >
      <div>
        {/* Top Row: App Icon & Price Badge */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-[#180f33] border border-purple-700/40 p-0.5 shrink-0 group-hover:border-purple-500 transition-colors">
            {!imageError && app.iconUrl ? (
              <img
                src={app.iconUrl}
                alt={app.name}
                onError={() => setImageError(true)}
                className="w-full h-full object-cover rounded-[14px]"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full rounded-[14px] bg-gradient-to-br from-purple-700 via-indigo-800 to-blue-900 flex items-center justify-center">
                <Disc3 className="w-8 h-8 text-purple-200" />
              </div>
            )}
          </div>

          <div className="flex flex-col items-end gap-1.5">
            {isFree ? (
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2.5 py-0.5 rounded-lg">
                FREE
              </span>
            ) : (
              <span className="text-sm font-black text-purple-300 bg-purple-950/80 border border-purple-700/60 px-2.5 py-0.5 rounded-lg font-mono">
                ₹{app.price}
              </span>
            )}

            {app.isTrending && (
              <span className="text-[10px] font-semibold text-orange-400 flex items-center gap-0.5">
                <Flame className="w-3 h-3" /> Trending
              </span>
            )}
          </div>
        </div>

        {/* App Title & Category */}
        <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors line-clamp-1 mb-1">
          {app.name}
        </h3>

        {/* Clean Unboxed Metadata */}
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-2.5">
          <span>{app.category}</span>
          <span aria-hidden="true">·</span>
          <span>v{app.version}</span>
          <span aria-hidden="true">·</span>
          <span>{app.sizeMb} MB</span>
        </div>

        {/* Short Description */}
        <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-4">
          {app.shortDesc || app.description}
        </p>
      </div>

      {/* Card Footer: Rating, Downloads & Action CTA */}
      <div className="pt-3 border-t border-purple-900/20 flex items-center justify-between gap-2">
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-1 text-yellow-400">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="font-semibold text-slate-200">{app.rating.toFixed(1)}</span>
          </div>
          <span aria-hidden="true">·</span>
          <span>{app.downloadsCount.toLocaleString()} DLs</span>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onQuickDownload(app);
          }}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
            isFree
              ? 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30'
              : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-600/30'
          }`}
        >
          {isFree ? (
            <Download className="w-3.5 h-3.5" />
          ) : (
            <Lock className="w-3.5 h-3.5 text-purple-200" />
          )}
          <span>{isFree ? 'Download' : `Unlock ₹${app.price}`}</span>
        </button>
      </div>
    </div>
  );
};
