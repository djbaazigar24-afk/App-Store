import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  QrCode,
  Smartphone,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Download,
  Loader2,
  Sparkles,
  Zap,
  ArrowRight,
} from 'lucide-react';
import { AppItem } from '../types';

interface PaymentModalProps {
  app: AppItem | null;
  onClose: () => void;
  onPaymentSuccess: (orderId: string, downloadToken: string, app: AppItem) => void;
}

interface OrderData {
  order_id: string;
  internal_id: string;
  app_id: string;
  app_name: string;
  amount: number;
  payable_amount: number;
  upi_id: string;
  qr_url: string;
  qr_data_url?: string;
  checkout_url: string;
  upi_intent: string;
  expires_at: number;
  is_live_gateway: boolean;
}

// Synthesize pleasant celebratory chime on payment success
function playSuccessChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const chords = [
      { f: 523.25, t: 0 },
      { f: 659.25, t: 0.08 },
      { f: 783.99, t: 0.16 },
      { f: 1046.5, t: 0.24 },
      { f: 1318.5, t: 0.36 },
    ];
    chords.forEach(({ f, t }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, ctx.currentTime + t);
      gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.65);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + t);
      osc.stop(ctx.currentTime + t + 0.7);
    });
  } catch {
    // Non-critical if browser policy prevents audio
  }
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  app,
  onClose,
  onPaymentSuccess,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [order, setOrder] = useState<OrderData | null>(null);
  const [status, setStatus] = useState<'PENDING' | 'SUCCESS' | 'EXPIRED' | 'FAILED'>('PENDING');
  const [paymentDetails, setPaymentDetails] = useState<{
    utr?: string;
    transaction_id?: string;
    sender_name?: string;
    download_token?: string;
  }>({});

  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedAmount, setCopiedAmount] = useState(false);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(600);
  const [activeTab, setActiveTab] = useState<'qr' | 'intent'>('qr');
  const [isCheckingManual, setIsCheckingManual] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  const pollIntervalRef = useRef<any>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // 1. Create Order on Mount
  useEffect(() => {
    if (!app || app.price <= 0) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    fetch('/api/payment/create-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        appId: app.id,
        customerName: 'DJ Baazigar Customer',
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (!isMounted) return;
        if (data.status === 'success' && data.data) {
          setOrder(data.data);
          const remaining = Math.max(0, Math.floor((data.data.expires_at - Date.now()) / 1000));
          setTimeLeftSeconds(remaining > 0 ? remaining : 600);
          setLoading(false);
        } else {
          setError(data.error || 'Failed to initialize payment gateway.');
          setLoading(false);
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        console.error('Order creation network error:', err);
        setError('Network error connecting to payment gateway.');
        setLoading(false);
      });

    return () => {
      isMounted = false;
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [app]);

  // 2. Countdown timer
  useEffect(() => {
    if (status !== 'PENDING' || timeLeftSeconds <= 0) return;

    const timer = setInterval(() => {
      setTimeLeftSeconds((prev) => {
        if (prev <= 1) {
          setStatus('EXPIRED');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [status, timeLeftSeconds]);

  // Helper when payment succeeds
  const handlePaymentConfirmed = (data: any) => {
    setStatus('SUCCESS');
    setPaymentDetails({
      utr: data.utr || 'VERIFIED',
      transaction_id: data.transaction_id || `FMP${Date.now()}`,
      sender_name: data.sender_name || 'Verified Payer',
      download_token: data.download_token,
    });

    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);

    playSuccessChime();

    // Trigger parent success callback
    if (app && data.download_token) {
      onPaymentSuccess(order?.order_id || '', data.download_token, app);
    }
  };

  // 3. Automatic Status Polling (Every 3.2 seconds against FamGateway)
  useEffect(() => {
    if (!order || status !== 'PENDING') return;

    const checkStatus = async () => {
      try {
        const res = await fetch(`/api/payment/checkout-status?order_id=${encodeURIComponent(order.order_id)}`);
        const data = await res.json();

        if (data.status === 'success') {
          handlePaymentConfirmed(data);
        } else if (data.status === 'expired') {
          setStatus('EXPIRED');
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
        }
      } catch (err) {
        // Silent catch for periodic polling
      }
    };

    pollIntervalRef.current = setInterval(checkStatus, 3200);

    return () => {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [order, status, app]);

  // Manual payment verification check by user
  const handleManualCheckStatus = async () => {
    if (!order || isCheckingManual) return;
    setIsCheckingManual(true);
    try {
      const res = await fetch(`/api/payment/checkout-status?order_id=${encodeURIComponent(order.order_id)}`);
      const data = await res.json();
      if (data.status === 'success') {
        handlePaymentConfirmed(data);
      } else if (data.status === 'expired') {
        setStatus('EXPIRED');
      }
    } catch (e) {
      console.error('Manual check error:', e);
    } finally {
      setIsCheckingManual(false);
    }
  };

  // 4. Confetti & Particle Animation on Success
  useEffect(() => {
    if (status !== 'SUCCESS') return;

    // Progress bar animation
    let prog = 0;
    const progTimer = setInterval(() => {
      prog += 12;
      if (prog >= 100) {
        setDownloadProgress(100);
        clearInterval(progTimer);
      } else {
        setDownloadProgress(prog);
      }
    }, 100);

    // Canvas particle confetti
    const canvas = canvasRef.current;
    if (!canvas) return () => clearInterval(progTimer);

    const ctx = canvas.getContext('2d');
    if (!ctx) return () => clearInterval(progTimer);

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const colors = ['#a855f7', '#10b981', '#3b82f6', '#f59e0b', '#ec4899', '#06b6d4'];
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      color: string;
      vx: number;
      vy: number;
      rotation: number;
      vRot: number;
      alpha: number;
    }> = [];

    for (let i = 0; i < 90; i++) {
      particles.push({
        x: canvas.width / 2 + (Math.random() - 0.5) * 60,
        y: canvas.height * 0.35 + (Math.random() - 0.5) * 40,
        size: Math.random() * 8 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: (Math.random() - 0.5) * 14,
        vy: (Math.random() - 0.9) * 16,
        rotation: Math.random() * 360,
        vRot: (Math.random() - 0.5) * 10,
        alpha: 1,
      });
    }

    let animationId: number;
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = false;

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.35; // Gravity
        p.rotation += p.vRot;
        p.alpha -= 0.007; // Fade

        if (p.alpha > 0) {
          alive = true;
          ctx.save();
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.translate(p.x, p.y);
          ctx.rotate((p.rotation * Math.PI) / 180);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 10;
          ctx.shadowColor = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 1.4);
          ctx.restore();
        }
      });

      if (alive) {
        animationId = requestAnimationFrame(render);
      }
    };

    animationId = requestAnimationFrame(render);

    return () => {
      clearInterval(progTimer);
      cancelAnimationFrame(animationId);
    };
  }, [status]);

  if (!app) return null;

  const handleCopy = (text: string, type: 'upi' | 'amount') => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      if (type === 'upi') {
        setCopiedUpi(true);
        setTimeout(() => setCopiedUpi(false), 2000);
      } else {
        setCopiedAmount(true);
        setTimeout(() => setCopiedAmount(false), 2000);
      }
    }
  };

  const handleOpenUpiApp = () => {
    if (!order?.upi_intent) return;
    try {
      window.location.href = order.upi_intent;
    } catch (e) {
      console.warn('Could not launch UPI application directly:', e);
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div
        className="relative w-full max-w-lg bg-[#0d071d] border border-purple-700/50 rounded-3xl overflow-hidden shadow-2xl shadow-purple-950 my-6 animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header Bar */}
        <div className="p-5 border-b border-purple-900/40 flex items-center justify-between bg-[#120a27]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden bg-purple-900/40 border border-purple-600/40 p-0.5 shrink-0">
              <img
                src={app.iconUrl}
                alt={app.name}
                className="w-full h-full object-cover rounded-[10px]"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white line-clamp-1">{app.name}</h3>
              <span className="text-xs text-purple-400 font-semibold flex items-center gap-1">
                <Zap className="w-3 h-3 text-yellow-400" />
                <span>FamGateway UPI Instant Payment</span>
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-purple-950/60 hover:bg-purple-900 text-slate-300 hover:text-white flex items-center justify-center border border-purple-700/30 transition-all cursor-pointer"
            aria-label="Close payment modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="p-14 text-center space-y-4">
            <Loader2 className="w-10 h-10 text-purple-500 animate-spin mx-auto" />
            <p className="text-sm text-slate-300 font-medium">Connecting to FamGateway UPI server...</p>
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="p-8 text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto" />
            <h4 className="text-base font-bold text-white">Payment Gateway Unavailable</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold cursor-pointer"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* Expired State */}
        {status === 'EXPIRED' && !loading && (
          <div className="p-8 text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-yellow-400 mx-auto" />
            <h4 className="text-base font-bold text-white">Payment Session Expired</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Your 10-minute UPI payment session has timed out. Please generate a fresh QR code.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 mx-auto cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Generate New Payment Order</span>
            </button>
          </div>
        )}

        {/* SUCCESS STATE WITH SPECTACULAR CELEBRATION ANIMATION */}
        {status === 'SUCCESS' && !loading && (
          <div className="relative p-6 sm:p-8 text-center space-y-6 overflow-hidden">
            {/* Particle Confetti Canvas Overlay */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 pointer-events-none w-full h-full z-10"
            />

            {/* Glowing Concentric Rings & Animated Checkmark */}
            <div className="relative mx-auto w-24 h-24 flex items-center justify-center">
              {/* Outer pulsing neon rings */}
              <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping opacity-60" />
              <div className="absolute -inset-2 rounded-full border-2 border-emerald-400/30 animate-pulse" />
              <div className="absolute inset-2 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 shadow-[0_0_40px_rgba(16,185,129,0.7)] flex items-center justify-center">
                <Check className="w-12 h-12 text-white stroke-[3] animate-in zoom-in-75 duration-300" />
              </div>
            </div>

            <div className="space-y-1 relative z-20">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-black tracking-wider uppercase shadow-lg shadow-emerald-950/50">
                <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-spin" />
                <span>PAYMENT VERIFIED • 100% SUCCESS</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                APK Download Unlocked!
              </h3>
              <p className="text-xs text-slate-300">
                Your payment of <strong className="text-white">₹{order?.payable_amount}</strong> was automatically verified by FamGateway.
              </p>
            </div>

            {/* Dynamic Download Progress Animation */}
            <div className="space-y-2 relative z-20 bg-[#140b2a]/90 p-3 rounded-2xl border border-emerald-500/30">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-emerald-400 flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5 animate-bounce" />
                  {downloadProgress < 100 ? 'Starting Automatic Download...' : 'Download Started to Your Device!'}
                </span>
                <span className="font-mono text-white">{downloadProgress}%</span>
              </div>
              <div className="w-full h-2.5 bg-purple-950 rounded-full overflow-hidden border border-purple-800/40">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 rounded-full transition-all duration-300 shadow-[0_0_15px_rgba(16,185,129,0.9)]"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
            </div>

            {/* Verified Digital Receipt */}
            <div className="p-4 rounded-2xl bg-[#140b2a] border border-purple-800/40 text-xs space-y-2 text-left relative z-20">
              <div className="flex justify-between py-1 border-b border-purple-900/30">
                <span className="text-slate-400">Order ID:</span>
                <span className="font-mono text-purple-200 font-semibold">{order?.order_id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-purple-900/30">
                <span className="text-slate-400">UTR / Ref No:</span>
                <span className="font-mono text-emerald-300 font-bold">{paymentDetails.utr}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-purple-900/30">
                <span className="text-slate-400">Transaction ID:</span>
                <span className="font-mono text-slate-300">{paymentDetails.transaction_id}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Verification Status:</span>
                <span className="font-bold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  PAID & AUTHORIZED
                </span>
              </div>
            </div>

            {/* Direct APK Download Button (in case browser blocked popup) */}
            <div className="space-y-2 relative z-20">
              <a
                href={`/api/download/apk/${app.id}?token=${paymentDetails.download_token || ''}`}
                download
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-xl shadow-emerald-950 transition-all text-sm cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download {app.name} APK File</span>
              </a>
              <p className="text-[11px] text-slate-400">
                If the download did not start automatically on your phone, tap the button above.
              </p>
            </div>
          </div>
        )}

        {/* MAIN PENDING PAYMENT SCREEN (100% PRODUCTION) */}
        {status === 'PENDING' && order && !loading && (
          <div className="p-5 sm:p-6 space-y-5">
            {/* Amount Banner & Real Countdown */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/90 via-indigo-950/90 to-purple-950/90 border border-purple-700/50 flex items-center justify-between shadow-lg shadow-purple-950">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-purple-300 font-semibold block">
                  Total Payable Amount
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-black text-white font-mono">
                    ₹{order.payable_amount.toFixed(2)}
                  </span>
                  <span className="text-xs text-purple-300 font-mono font-bold">INR</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] uppercase tracking-wider text-slate-400 block">
                  Session Expiry
                </span>
                <span className="text-base sm:text-lg font-mono font-bold text-yellow-400">
                  {formatTimer(timeLeftSeconds)}
                </span>
              </div>
            </div>

            {/* Tab Selector: Scan QR vs Pay via App */}
            <div className="grid grid-cols-2 p-1 bg-[#140b2a] rounded-xl border border-purple-900/40 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('qr')}
                className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'qr'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Scan Dynamic QR</span>
              </button>
              <button
                onClick={() => setActiveTab('intent')}
                className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'intent'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Pay via UPI App</span>
              </button>
            </div>

            {/* View A: Dynamic QR View */}
            {activeTab === 'qr' && (
              <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-white text-slate-900 text-center shadow-inner">
                <div className="w-48 h-48 sm:w-56 sm:h-56 relative bg-white flex items-center justify-center p-1 rounded-xl">
                  {order.qr_data_url ? (
                    <img
                      src={order.qr_data_url}
                      alt="FamGateway UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <img
                      src={order.qr_url}
                      alt="FamGateway UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  )}
                </div>

                <div className="mt-2 text-xs font-bold text-slate-800">
                  Scan with Google Pay, PhonePe, Paytm, BHIM, or any UPI App
                </div>
                <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                  Order ID: {order.order_id}
                </div>
              </div>
            )}

            {/* View B: Mobile App Buttons (Google Pay, PhonePe, Paytm, BHIM) */}
            {activeTab === 'intent' && (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 text-center">
                  Tap your installed UPI app on your Android phone to pay instantly:
                </p>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    onClick={handleOpenUpiApp}
                    className="p-3 rounded-xl bg-[#140b2a] hover:bg-[#1f1140] border border-purple-800/40 hover:border-purple-500 flex items-center gap-3 transition-all cursor-pointer text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-white p-1 flex items-center justify-center shrink-0">
                      <span className="font-black text-xs text-blue-600">GPay</span>
                    </div>
                    <div className="text-xs font-bold text-white">Google Pay</div>
                  </button>

                  <button
                    onClick={handleOpenUpiApp}
                    className="p-3 rounded-xl bg-[#140b2a] hover:bg-[#1f1140] border border-purple-800/40 hover:border-purple-500 flex items-center gap-3 transition-all cursor-pointer text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#5f259f] p-1 flex items-center justify-center shrink-0">
                      <span className="font-black text-xs text-white">पे</span>
                    </div>
                    <div className="text-xs font-bold text-white">PhonePe</div>
                  </button>

                  <button
                    onClick={handleOpenUpiApp}
                    className="p-3 rounded-xl bg-[#140b2a] hover:bg-[#1f1140] border border-purple-800/40 hover:border-purple-500 flex items-center gap-3 transition-all cursor-pointer text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#002e6e] p-1 flex items-center justify-center shrink-0">
                      <span className="font-black text-xs text-[#00baf2]">Paytm</span>
                    </div>
                    <div className="text-xs font-bold text-white">Paytm UPI</div>
                  </button>

                  <button
                    onClick={handleOpenUpiApp}
                    className="p-3 rounded-xl bg-[#140b2a] hover:bg-[#1f1140] border border-purple-800/40 hover:border-purple-500 flex items-center gap-3 transition-all cursor-pointer text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#008080] p-1 flex items-center justify-center shrink-0">
                      <span className="font-black text-xs text-white">BHIM</span>
                    </div>
                    <div className="text-xs font-bold text-white">BHIM UPI</div>
                  </button>
                </div>

                {/* Direct Generic Intent CTA */}
                <button
                  onClick={handleOpenUpiApp}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-purple-900/40 transition-all cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Open Installed UPI App</span>
                </button>
              </div>
            )}

            {/* Quick Copy UPI ID & Amount */}
            <div className="p-3 rounded-xl bg-[#120a26] border border-purple-900/40 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">FamGateway Merchant UPI:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-purple-300 font-semibold">{order.upi_id}</span>
                  <button
                    onClick={() => handleCopy(order.upi_id, 'upi')}
                    className="p-1 rounded hover:bg-purple-900/50 text-slate-300 hover:text-white cursor-pointer"
                    title="Copy UPI ID"
                  >
                    {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Payable Amount:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-white font-semibold">₹{order.payable_amount.toFixed(2)}</span>
                  <button
                    onClick={() => handleCopy(order.payable_amount.toString(), 'amount')}
                    className="p-1 rounded hover:bg-purple-900/50 text-slate-300 hover:text-white cursor-pointer"
                    title="Copy Amount"
                  >
                    {copiedAmount ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Real Automated Verification Pulse & Manual Refresh Action */}
            <div className="p-3 rounded-xl bg-[#100722] border border-purple-900/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span>Auto-verifying payment with FamGateway...</span>
              </div>

              <button
                type="button"
                onClick={handleManualCheckStatus}
                disabled={isCheckingManual}
                className="px-3 py-1.5 rounded-lg bg-purple-900/50 hover:bg-purple-800 text-purple-200 hover:text-white font-semibold flex items-center gap-1.5 text-xs transition-colors cursor-pointer shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isCheckingManual ? 'animate-spin' : ''}`} />
                <span>{isCheckingManual ? 'Verifying...' : 'Check Status'}</span>
              </button>
            </div>

            {/* Hosted FamGateway Checkout Link */}
            {order.checkout_url && (
              <div className="pt-1 text-center">
                <a
                  href={order.checkout_url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-purple-400 hover:text-purple-300 hover:underline inline-flex items-center gap-1"
                >
                  <span>Or open Hosted FamGateway Payment Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>
        )}

        {/* Footer Guarantee */}
        <div className="p-3 bg-[#0a0517] border-t border-purple-900/30 flex items-center justify-center gap-2 text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>256-Bit Encrypted · Instant Auto-Delivery · FamGateway Verified</span>
        </div>
      </div>
    </div>
  );
};
