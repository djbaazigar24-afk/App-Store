import React, { useState } from 'react';
import { Search, ShieldAlert, Disc3, Sparkles } from 'lucide-react';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenAdminLogin: () => void;
  isAdminLoggedIn: boolean;
  onOpenAdminDashboard: () => void;
  onNavigateSection: (sectionId: string) => void;
  siteName: string;
  siteLogo?: string;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  onOpenAdminLogin,
  isAdminLoggedIn,
  onOpenAdminDashboard,
  onNavigateSection,
  siteName,
  siteLogo,
}) => {
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Check if search query matches the exact secret trigger keyword "ADMIN"
  const isSecretAdminDetected = searchQuery.trim().toUpperCase() === 'ADMIN';

  return (
    <header className="sticky top-0 z-40 bg-[#06040d]/90 backdrop-blur-md border-b border-purple-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onNavigateSection('hero');
          }}
          className="flex items-center gap-3 shrink-0 group focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-600 p-0.5 shadow-lg shadow-purple-600/30 group-hover:shadow-purple-500/50 transition-all duration-300">
            {siteLogo ? (
              <img src={siteLogo} alt={siteName} className="w-full h-full object-cover rounded-[10px]" />
            ) : (
              <div className="w-full h-full bg-[#090514] rounded-[10px] flex items-center justify-center">
                <Disc3 className="w-5 h-5 text-purple-400 group-hover:rotate-180 transition-transform duration-700" />
              </div>
            )}
          </div>
          <div>
            <span className="text-lg sm:text-xl font-bold tracking-tight text-white whitespace-nowrap block">
              {siteName || 'DJ BAAZIGAR'}
            </span>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-400/80 -mt-1 block">
              PREMIUM VIP STORE
            </span>
          </div>
        </a>

        {/* Zone 2: Search Bar with Secret Admin Access Detection */}
        <div className="flex-1 max-w-md relative hidden sm:block">
          <div
            className={`relative flex items-center rounded-xl bg-[#120a24]/90 border transition-all duration-200 ${
              isSearchFocused
                ? 'border-purple-500 shadow-[0_0_20px_rgba(168,85,247,0.25)] ring-1 ring-purple-500/40'
                : 'border-purple-900/40 hover:border-purple-700/60'
            }`}
          >
            <Search className="w-4 h-4 text-purple-400/70 ml-3.5 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && isSecretAdminDetected) {
                  e.preventDefault();
                  onOpenAdminLogin();
                }
              }}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
              placeholder="Search DJ modz, 8D audio, VIP tools..."
              className="w-full bg-transparent py-2.5 pl-3 pr-28 text-sm text-white placeholder-slate-500 focus:outline-none"
              aria-label="Search applications"
            />

            {/* Secret Admin Entry Button (Revealed only when keyword is exactly 'ADMIN') */}
            {isSecretAdminDetected && (
              <button
                type="button"
                onClick={onOpenAdminLogin}
                className="absolute right-1.5 px-3 py-1 bg-gradient-to-r from-red-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-md shadow-red-900/40 animate-pulse transition-all cursor-pointer"
                title="Secret Admin Console (or press Enter)"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Admin Entry</span>
              </button>
            )}
          </div>
        </div>

        {/* Zone 3: Navigation Links & Action */}
        <div className="flex items-center gap-6 shrink-0">
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
            <button
              onClick={() => onNavigateSection('apps-catalog')}
              className="hover:text-purple-400 transition-colors whitespace-nowrap cursor-pointer"
            >
              All Apps
            </button>
            <button
              onClick={() => onNavigateSection('trending')}
              className="hover:text-purple-400 transition-colors whitespace-nowrap cursor-pointer"
            >
              Trending
            </button>
            <button
              onClick={() => onNavigateSection('categories')}
              className="hover:text-purple-400 transition-colors whitespace-nowrap cursor-pointer"
            >
              Categories
            </button>
            <button
              onClick={() => onNavigateSection('about')}
              className="hover:text-purple-400 transition-colors whitespace-nowrap cursor-pointer"
            >
              About
            </button>
          </nav>

          {isAdminLoggedIn ? (
            <button
              onClick={onOpenAdminDashboard}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer whitespace-nowrap"
            >
              <Sparkles className="w-4 h-4 text-purple-200" />
              <span>Super Admin Panel</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigateSection('apps-catalog')}
              className="px-4 py-2 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 hover:border-purple-500/60 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer whitespace-nowrap"
            >
              Explore VIP Modz
            </button>
          )}
        </div>
      </div>

      {/* Mobile Search Bar Row */}
      <div className="sm:hidden px-4 pb-3">
        <div className="relative flex items-center rounded-xl bg-[#120a24] border border-purple-900/40">
          <Search className="w-4 h-4 text-purple-400/70 ml-3 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search applications..."
            className="w-full bg-transparent py-2 pl-2.5 pr-28 text-sm text-white placeholder-slate-500 focus:outline-none"
            aria-label="Search applications mobile"
          />
          {isSecretAdminDetected && (
            <button
              type="button"
              onClick={onOpenAdminLogin}
              className="absolute right-1 px-2.5 py-1 bg-red-600 text-white text-xs font-semibold rounded-lg flex items-center gap-1 animate-pulse"
            >
              <ShieldAlert className="w-3 h-3" />
              <span>Admin</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
