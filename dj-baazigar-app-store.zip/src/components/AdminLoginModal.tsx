import React, { useState } from 'react';
import { X, Lock, Eye, EyeOff, ShieldCheck, AlertCircle, Loader2 } from 'lucide-react';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (token: string) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError('Password is required');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();
      if (res.ok && data.status === 'success' && data.token) {
        localStorage.setItem('dj_admin_token', data.token);
        onLoginSuccess(data.token);
        setPassword('');
        onClose();
      } else {
        setError(data.error || 'Authentication failed. Check your password.');
      }
    } catch (err) {
      setError('Connection to security terminal failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div
        className="relative w-full max-w-md bg-[#0e0720] border border-red-500/30 rounded-3xl overflow-hidden shadow-2xl shadow-red-950/40 p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-purple-950/60 hover:bg-purple-900/80 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          aria-label="Close admin modal"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-3 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-red-950/50 border border-red-600/40 flex items-center justify-center mx-auto text-red-400">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black tracking-tight text-white">
            ADMIN TERMINAL ACCESS
          </h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Authorized Super Administrators only. System actions and IP addresses are recorded.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-800/60 text-xs text-red-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              Admin Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password..."
                className="w-full bg-[#160c33] border border-purple-900/60 focus:border-red-500 focus:ring-1 focus:ring-red-500/40 rounded-xl py-3 pl-4 pr-11 text-sm text-white placeholder-slate-500 focus:outline-none font-mono"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1 cursor-pointer"
                aria-label="Toggle password visibility"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Default master key: <code className="text-purple-300">ADMIN</code></p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-red-600 via-purple-700 to-indigo-700 hover:from-red-500 hover:to-indigo-600 text-white font-bold rounded-xl text-sm shadow-xl shadow-red-950/50 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.98]"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ShieldCheck className="w-4 h-4" />
            )}
            <span>{loading ? 'Authenticating...' : 'Authenticate & Enter Dashboard'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
