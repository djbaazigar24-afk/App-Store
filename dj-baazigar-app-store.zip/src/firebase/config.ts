/**
 * Firebase Client Configuration
 * Derived from user's attached google-services.json
 * Public web client configuration for DJ Baazigar App Store
 */

export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyBsCkodaAoZnPdvgnY1IsstOLtHqMv492I',
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || 'dj-jomraj-modz'}.firebaseapp.com`,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || 'https://dj-jomraj-modz-default-rtdb.firebaseio.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'dj-jomraj-modz',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'dj-jomraj-modz.firebasestorage.app',
  messagingSenderId: '635200284671',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:635200284671:android:f9a6d1471dcb9eebd3e9ca',
};

export const isFirebaseConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
