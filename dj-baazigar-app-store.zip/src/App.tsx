import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AnnouncementBar } from './components/AnnouncementBar';
import { HeroSection } from './components/HeroSection';
import { CategoryFilter } from './components/CategoryFilter';
import { AppCard } from './components/AppCard';
import { AppDetailModal } from './components/AppDetailModal';
import { PaymentModal } from './components/PaymentModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Footer } from './components/Footer';
import { InfoModals } from './components/InfoModals';
import { AppItem, WebsiteSettings } from './types';
import { Flame, Star, Sparkles, Filter, AlertOctagon } from 'lucide-react';

const defaultSettings: WebsiteSettings = {
  siteName: 'DJ BAAZIGAR APP STORE',
  siteTitle: 'DJ Baazigar VIP Android Apps & Modz Marketplace',
  siteDescription: 'Exclusive premium Android Modz, DJ Mixers, and VIP Tools with instant UPI verification and high-speed APK downloads.',
  announcementBanner: '⚡ FLASH SALE: DJ Baazigar Music Modz VIP v4.8 is now live! Download with instant UPI unlock.',
  announcementEnabled: true,
  heroBadge: 'OFFICIAL DJ BAAZIGAR STORE',
  heroHeadline: 'NEXT-GEN VIP ANDROID MODZ & AUDIO SUITES',
  heroSubtitle: 'Download high-performance DJ mixers, VIP gaming modz, and exclusive audio tools. 100% Virus-Free & Instant UPI Access.',
  primaryColor: '#a855f7',
  secondaryColor: '#3b82f6',
  contactWhatsApp: '+91 98765 43210',
  contactTelegram: '@dj_baazigar_official',
  contactEmail: 'avijit86259779@gmail.com',
  contactPhone: '+91 98765 43210',
  maintenanceMode: false,
  allowDirectFreeDownloads: true,
  currencySymbol: '₹',
};

export default function App() {
  const [apps, setApps] = useState<AppItem[]>([]);
  const [settings, setSettings] = useState<WebsiteSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'price_low' | 'price_high'>('popular');

  // Modals
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(null);
  const [paymentApp, setPaymentApp] = useState<AppItem | null>(null);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [adminDashboardOpen, setAdminDashboardOpen] = useState(false);
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [infoModalType, setInfoModalType] = useState<'about' | 'privacy' | 'terms' | null>(null);

  // Check stored admin token
  useEffect(() => {
    const stored = localStorage.getItem('dj_admin_token');
    if (stored) {
      fetch('/api/admin/verify-session', {
        headers: { Authorization: `Bearer ${stored}` },
      })
        .then((res) => {
          if (res.ok) {
            setAdminToken(stored);
          } else {
            localStorage.removeItem('dj_admin_token');
          }
        })
        .catch(() => {});
    }
  }, []);

  // Fetch apps & settings, ping visitor counter
  const loadStore = React.useCallback(async () => {
    try {
      const [appsRes, settingsRes] = await Promise.all([
        fetch('/api/apps'),
        fetch('/api/settings'),
      ]);

      if (appsRes.ok) setApps(await appsRes.json());
      if (settingsRes.ok) setSettings(await settingsRes.json());

      // Increment visitor count quietly
      fetch('/api/visitor-ping', { method: 'POST' }).catch(() => {});
    } catch (err) {
      console.error('Error loading store data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStore();
  }, [loadStore]);

  // Sync document title and meta description with custom settings
  useEffect(() => {
    if (settings.siteTitle) {
      document.title = settings.siteTitle;
    }
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && settings.siteDescription) {
      metaDesc.setAttribute('content', settings.siteDescription);
    }
  }, [settings]);

  // Handle direct download or launch payment
  const handleInitiateDownloadOrBuy = (app: AppItem) => {
    if (app.price === 0) {
      // Free app direct download
      window.location.href = `/api/download/apk/${app.id}`;
      // Increment local count feedback
      setApps((prev) =>
        prev.map((a) => (a.id === app.id ? { ...a, downloadsCount: a.downloadsCount + 1 } : a))
      );
    } else {
      // Paid VIP app via FamGateway UPI
      setPaymentApp(app);
    }
  };

  // On payment success: automatically trigger APK download
  const handlePaymentSuccess = (orderId: string, downloadToken: string, app: AppItem) => {
    const downloadUrl = `/api/download/apk/${app.id}?token=${downloadToken}`;
    // Trigger download in browser
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${app.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_v${app.version}_DJBaazigar.apk`;
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleAdminLogout = () => {
    if (adminToken) {
      fetch('/api/admin/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` },
      }).catch(() => {});
    }
    localStorage.removeItem('dj_admin_token');
    setAdminToken(null);
    setAdminDashboardOpen(false);
  };

  // Derive categories & counts
  const categories = ['All', 'DJ & Music Modz', 'VIP Audio Tools', 'Game Boosters', 'Utility Tools'];
  const categoryCounts: Record<string, number> = {};
  apps.forEach((a) => {
    categoryCounts[a.category] = (categoryCounts[a.category] || 0) + 1;
  });

  // Filter & sort apps
  const filteredApps = apps
    .filter((a) => {
      const matchesCategory = activeCategory === 'All' || a.category === activeCategory;
      const matchesSearch =
        searchQuery === '' ||
        a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'popular') return (b.downloadsCount || 0) - (a.downloadsCount || 0);
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      if (sortBy === 'price_low') return a.price - b.price;
      if (sortBy === 'price_high') return b.price - a.price;
      return 0;
    });

  // Trending & Featured apps
  const trendingApps = apps.filter((a) => a.isTrending || a.rating >= 4.9).slice(0, 4);

  // Navigation helper
  const handleNavigateSection = (sectionId: string) => {
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Maintenance mode screen
  if (settings.maintenanceMode && !adminToken) {
    return (
      <div className="min-h-screen bg-[#070311] flex flex-col items-center justify-center p-6 text-center text-white">
        <div className="w-16 h-16 rounded-2xl bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center mb-4 text-yellow-400">
          <AlertOctagon className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold mb-2">{settings.siteName} is Updating</h1>
        <p className="text-sm text-slate-400 max-w-md mb-6">
          Our VIP servers and FamGateway payment gateways are undergoing scheduled optimization. We will be live shortly.
        </p>
        <button
          onClick={() => setAdminLoginOpen(true)}
          className="text-xs text-purple-400 hover:underline"
        >
          Administrator Access
        </button>
        <AdminLoginModal
          isOpen={adminLoginOpen}
          onClose={() => setAdminLoginOpen(false)}
          onLoginSuccess={(tok) => {
            setAdminToken(tok);
            setAdminDashboardOpen(true);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05040a] text-slate-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Top Announcement Bar */}
      <AnnouncementBar text={settings.announcementBanner} enabled={settings.announcementEnabled} />

      {/* Main Top Navigation Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenAdminLogin={() => setAdminLoginOpen(true)}
        isAdminLoggedIn={Boolean(adminToken)}
        onOpenAdminDashboard={() => setAdminDashboardOpen(true)}
        onNavigateSection={handleNavigateSection}
        siteName={settings.siteName}
        siteLogo={settings.siteLogo}
      />

      {/* Hero Showcase Section */}
      <HeroSection
        settings={settings}
        onExploreClick={() => handleNavigateSection('apps-catalog')}
        onTrendingClick={() => handleNavigateSection('trending')}
      />

      {/* Main Public Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 pb-20 w-full">
        {/* Section 1: Trending & VIP Highlights */}
        {trendingApps.length > 0 && searchQuery === '' && activeCategory === 'All' && (
          <section id="trending" className="pt-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 mb-1">
                  <Flame className="w-4 h-4" />
                  <span>VIP Hall of Fame</span>
                </div>
                <h2 className="text-2xl font-black text-white">Trending Applications</h2>
              </div>
              <span className="text-xs text-slate-400">Most downloaded this week</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {trendingApps.map((app) => (
                <AppCard
                  key={app.id}
                  app={app}
                  onSelect={setSelectedApp}
                  onQuickDownload={handleInitiateDownloadOrBuy}
                />
              ))}
            </div>
          </section>
        )}

        {/* Section 2: Full Applications Catalog */}
        <section id="apps-catalog" className="space-y-6 pt-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-purple-900/30">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400 mb-1">
                <Sparkles className="w-4 h-4" />
                <span>Verified Android Modz & Sound Engines</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                {activeCategory === 'All' ? 'All Applications' : activeCategory}
              </h2>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2 text-xs text-slate-400 self-start md:self-auto">
              <Filter className="w-3.5 h-3.5 text-purple-400" />
              <span>Sort by:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-[#120a26] border border-purple-900/40 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none cursor-pointer"
              >
                <option value="popular">Most Popular</option>
                <option value="rating">Highest Rated</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* Interactive Category Tabs */}
          <CategoryFilter
            categories={categories}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            categoryCounts={categoryCounts}
          />

          {/* Applications Grid */}
          {loading ? (
            <div className="py-24 text-center text-slate-400">
              <div className="w-10 h-10 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-xs">Loading verified VIP applications...</p>
            </div>
          ) : filteredApps.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredApps.map((app) => (
                <AppCard
                  key={app.id}
                  app={app}
                  onSelect={setSelectedApp}
                  onQuickDownload={handleInitiateDownloadOrBuy}
                />
              ))}
            </div>
          ) : (
            <div className="py-16 text-center space-y-3 bg-[#0d071d] rounded-2xl border border-purple-900/30 p-8">
              <p className="text-sm font-semibold text-white">No applications found</p>
              <p className="text-xs text-slate-400">
                No apps matched your current search or category filter.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('All');
                }}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-xl cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}
        </section>

        {/* Section 3: About DJ Baazigar Story & Safety Guarantee */}
        <section id="about" className="p-8 rounded-3xl bg-gradient-to-br from-[#12092a] via-[#0d071c] to-[#080413] border border-purple-800/30 space-y-6">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
              About DJ Baazigar Marketplace
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Built for Sound Artists, Stage Performers & Power Users
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              DJ Baazigar represents the fusion of hard-hitting audio mastering, live sound FX modz, and extreme Android optimization. Every APK listed here is compiled, checked against signature collisions, and hosted on high-bandwidth servers.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-3.5 rounded-xl bg-[#180e35]/60 border border-purple-900/40">
                <div className="font-bold text-white text-sm">Instant Delivery</div>
                <div className="text-xs text-slate-400 mt-0.5">Automated FamGateway UPI unlock</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#180e35]/60 border border-purple-900/40">
                <div className="font-bold text-white text-sm">No Accounts Needed</div>
                <div className="text-xs text-slate-400 mt-0.5">Zero registration or login friction</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#180e35]/60 border border-purple-900/40">
                <div className="font-bold text-white text-sm">100% Virus Free</div>
                <div className="text-xs text-slate-400 mt-0.5">Clean APK guarantee on every build</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer settings={settings} onOpenModal={setInfoModalType} />

      {/* App Details Modal */}
      <AppDetailModal
        app={selectedApp}
        onClose={() => setSelectedApp(null)}
        onInitiateDownloadOrBuy={handleInitiateDownloadOrBuy}
      />

      {/* FamGateway Payment Modal */}
      {paymentApp && (
        <PaymentModal
          app={paymentApp}
          onClose={() => setPaymentApp(null)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Hidden Admin Login Modal */}
      <AdminLoginModal
        isOpen={adminLoginOpen}
        onClose={() => setAdminLoginOpen(false)}
        onLoginSuccess={(tok) => {
          setAdminToken(tok);
          setAdminDashboardOpen(true);
        }}
      />

      {/* Super Admin Dashboard */}
      {adminDashboardOpen && adminToken && (
        <AdminDashboard
          token={adminToken}
          onClose={() => setAdminDashboardOpen(false)}
          onLogout={handleAdminLogout}
          onUpdateStore={loadStore}
        />
      )}

      {/* About, Privacy & Terms Modals */}
      <InfoModals
        type={infoModalType}
        onClose={() => setInfoModalType(null)}
        siteName={settings.siteName}
      />
    </div>
  );
}
