export interface AppItem {
  id: string;
  name: string;
  packageName: string;
  version: string;
  sizeMb: number;
  category: string;
  price: number;
  rating: number;
  downloadsCount: number;
  iconUrl: string;
  bannerUrl?: string;
  screenshots: string[];
  shortDesc: string;
  description: string;
  features: string[];
  apkFileName?: string;
  apkDownloadUrl?: string;
  published: boolean;
  downloadsEnabled: boolean;
  isTrending?: boolean;
  isPopular?: boolean;
  isVip?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface PaymentTransaction {
  orderId: string;
  internalId: string;
  appId: string;
  appName: string;
  amount: number;
  payableAmount: number;
  upiId: string;
  status: 'CREATED' | 'PENDING' | 'SUCCESS' | 'EXPIRED' | 'FAILED';
  transactionId?: string;
  utr?: string;
  senderName?: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  qrUrl?: string;
  checkoutUrl?: string;
  upiIntent?: string;
  createdAt: number;
  paidAt?: number;
  expiresAt: number;
  downloadToken?: string;
}

export interface WebsiteSettings {
  siteName: string;
  siteTitle: string;
  siteDescription: string;
  siteLogo?: string;
  announcementBanner: string;
  announcementEnabled: boolean;
  heroBadge: string;
  heroHeadline: string;
  heroSubtitle: string;
  primaryColor: string;
  secondaryColor: string;
  contactWhatsApp: string;
  contactTelegram: string;
  contactEmail: string;
  contactPhone: string;
  maintenanceMode: boolean;
  allowDirectFreeDownloads: boolean;
  currencySymbol: string;
}

export interface AnalyticsData {
  totalVisitors: number;
  totalApplications: number;
  publishedApplications: number;
  totalDownloads: number;
  totalRevenue: number;
  successfulPaymentsCount: number;
  pendingPaymentsCount: number;
  expiredPaymentsCount: number;
  recentTransactions: PaymentTransaction[];
  categoryCounts: Record<string, number>;
}

export interface AuditLog {
  id: string;
  action: string;
  adminId: string;
  ip: string;
  details: string;
  timestamp: number;
}

export interface AdminSession {
  sessionId: string;
  ip: string;
  userAgent: string;
  createdAt: number;
  lastActive: number;
  expiresAt: number;
}
