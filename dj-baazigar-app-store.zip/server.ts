import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import dotenv from 'dotenv';
import { db } from './server/db';
import { paymentRouter } from './server/routes/payment';
import { downloadRouter } from './server/routes/download';
import { adminRouter } from './server/routes/admin';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Parse JSON and URL encoded request bodies (up to 50mb for APKs and photos)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure upload directory exists and serve uploads statically
const uploadsDir = path.resolve(process.cwd(), 'data', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Trust proxy for accurate IP determination (Cloud Run / reverse proxy)
app.set('trust proxy', 1);

// Security Headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// --- Public Store API Routes ---
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: Date.now(),
    store: 'DJ BAAZIGAR APP STORE',
  });
});

app.get('/api/settings', (req: Request, res: Response) => {
  const settings = db.getSettings();
  res.json(settings);
});

app.get('/api/apps', (req: Request, res: Response) => {
  const apps = db.getApps(false); // Only published apps for public
  res.json(apps);
});

app.get('/api/apps/:id', (req: Request, res: Response) => {
  const appItem = db.getAppById(req.params.id);
  if (!appItem || !appItem.published) {
    res.status(404).json({ error: 'Application not found' });
    return;
  }
  res.json(appItem);
});

app.post('/api/visitor-ping', (req: Request, res: Response) => {
  const count = db.incrementVisitor();
  res.json({ visitors: count });
});

// --- Mount Specialized Routers ---
app.use('/api/payment', paymentRouter);
app.use('/api/download', downloadRouter);
app.use('/api/admin', adminRouter);

// Legacy direct webhook fallback alias
app.post('/api/famgateway-webhook', (req, res, next) => {
  req.url = '/famgateway-webhook';
  paymentRouter(req, res, next);
});

// Start server with Vite middleware in dev or static files in prod
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    } else {
      console.warn('Production build dist/ not found. Running fallback mode.');
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 DJ BAAZIGAR APP STORE running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
