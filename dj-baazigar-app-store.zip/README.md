# DJ BAAZIGAR APP STORE — PREMIUM VIP MARKETPLACE

A production-ready, full-stack Android application marketplace built with React 19, TypeScript, Express, Tailwind CSS v4, and official **FamGateway Dynamic UPI Payment Integration**.

---

## 🌟 Key Highlights

- **Frictionless Public Experience**: No customer registration, no signup, no customer login required. Visitors can browse all applications, listen to previews, and download immediately.
- **FamGateway UPI Dynamic Integration**:
  - `POST /api/payment/create-order` calling `https://famgateway.in/api/create-order`
  - Dynamic QR generation & official `upi_intent` deep links for Google Pay, PhonePe, Paytm, BHIM UPI, and Amazon Pay
  - Automatic status polling every 3.5 seconds via `https://famgateway.in/api/checkout-status.php`
  - Authoritative server-side verification via `https://famgateway.in/api/verify-order.php`
  - Webhook listener `POST /api/famgateway-webhook` with HMAC-SHA256 signature verification (`X-FamGateway-Signature`)
  - Duplicate UTR protection & transaction replay defense
- **Automatic APK Download System**:
  - Short-lived HMAC-signed download tokens valid for 30 minutes
  - Secure APK delivery via `GET /api/download/apk/:appId?token=...` with `application/vnd.android.package-archive` MIME type
  - Free applications download without payment; VIP paid applications strictly require verified payment authorization
- **Hidden Admin Entry & Mobile Super Admin Panel**:
  - Hidden from ordinary visitors (no ordinary login link)
  - Type `ADMIN` in the search bar to reveal the secret **Admin Entry**
  - Protected by server-side PBKDF2 password hashing, rate limiting, and session tokens
  - Fully mobile-responsive for Android phones: Analytics, App Management (add/edit/delete/upload), FamGateway Transactions audit, Website Customization with live preview, and Security Audit Logs.
- **Firebase Integration**:
  - Configured with project `dj-jomraj-modz` (`google-services.json`)
  - Realtime Database security rules (`database.rules.json`)
  - Cloud Firestore security rules (`firestore.rules`)

---

## 🛠 Project Architecture

```
dj-baazigar-app-store/
├── server.ts                    # Full-Stack Express entry point & Vite dev middleware
├── server/
│   ├── types.ts                 # Backend data models
│   ├── db.ts                    # JSON persistent database store with seed VIP apps
│   ├── logic/
│   │   ├── paymentRules.ts      # UTR deduplication & amount validation
│   │   ├── downloadAuth.ts      # HMAC-SHA256 download token issuer & verifier
│   │   └── rules.test.ts        # Fast deterministic unit tests (node:test)
│   └── routes/
│       ├── payment.ts           # FamGateway API client & webhook handler
│       ├── download.ts          # Secure APK delivery & token validator
│       └── admin.ts             # Super Admin authentication, CRUD, and telemetry
├── src/
│   ├── types.ts                 # Client data models
│   ├── firebase/
│   │   └── config.ts            # Client Firebase configuration
│   ├── components/
│   │   ├── Header.tsx           # Navigation bar with secret "ADMIN" detection
│   │   ├── AnnouncementBar.tsx  # Top VIP flash alert ticker
│   │   ├── HeroSection.tsx      # High-impact banner & trust metric strip
│   │   ├── CategoryFilter.tsx   # Interactive category tabs & counts
│   │   ├── AppCard.tsx          # Cyberpunk app card with rating, price, & download CTA
│   │   ├── AppDetailModal.tsx   # Full technical specifications, screenshots & features
│   │   ├── PaymentModal.tsx     # FamGateway Dynamic UPI QR, intent buttons, auto-poll
│   │   ├── AdminLoginModal.tsx  # Secret admin credentials terminal
│   │   ├── Footer.tsx           # Contact details, WhatsApp, Telegram, and disclosures
│   │   ├── InfoModals.tsx       # About, Privacy Policy, Terms & Conditions
│   │   └── admin/
│   │       └── AdminDashboard.tsx # Complete Android-friendly Super Admin Panel
│   ├── App.tsx                  # Root application layout & state machine
│   ├── index.css                # Tailwind CSS v4 custom styling & glow utilities
│   └── main.tsx                 # React DOM mount point
├── database.rules.json          # Firebase Realtime Database rules
├── firestore.rules              # Firestore security rules
├── .env.example                 # Environment variables specification
└── package.json                 # Dependencies & scripts
```

---

## 🔐 Secret Admin Access Instructions

1. Go to the marketplace homepage.
2. In the top search bar, type the exact word:
   ```
   ADMIN
   ```
3. A glowing red-purple **Admin Entry** button will appear right inside the search box.
4. Click **Admin Entry** to open the secure Admin Terminal.
5. Enter the Master Admin Password:
   - Default Master Password: `ADMIN`
6. Once authenticated, the **Super Admin Panel** will slide in, giving you 100% control over applications, payments, website customization, and security logs directly on desktop or Android mobile.
7. Change the default password immediately in the **Security & Audit Logs** tab.

---

## 💳 FamGateway Configuration

Configure these environment variables in your `.env` file or hosting environment:

```env
FAMGATEWAY_API_KEY="YOUR_FAMGATEWAY_API_KEY"
FAMGATEWAY_UPI_ID="abhijit-dalui@fam"
FAMGATEWAY_BASE_URL="https://famgateway.in"
ADMIN_SESSION_SECRET="your-super-strong-jwt-secret-key"
```

### Webhook URL to configure in FamGateway Merchant Portal:
```
https://YOUR-DOMAIN.com/api/famgateway-webhook
```

The server automatically validates the HMAC-SHA256 signature in `X-FamGateway-Signature`, confirms the payable amount, ensures the UTR has never been processed before, marks the transaction as `SUCCESS`, and authorizes the download.

---

## 🧪 Testing and Verification

Run the unit tests:
```bash
npx --yes tsx --test server/logic/rules.test.ts
```

In the payment modal during development, click **"Simulate Successful UPI Payment (Test / Demo)"** to test the entire verified flow end-to-end without spending real money.

---

## 🚀 Deployment Instructions

### Option 1: Node.js / VPS / Docker / Cloud Run
1. Install dependencies:
   ```bash
   npm install
   ```
2. Build frontend production assets:
   ```bash
   npm run build
   ```
3. Start the production server:
   ```bash
   npm start
   ```
   (Starts `node server.ts` on port 3000 or the port specified in `process.env.PORT`).

### Option 2: Android Phone Access
- Open Google Chrome on your Android phone.
- Visit your deployed URL or local IP `http://YOUR-IP:3000`.
- All cards, forms, and the Admin Panel are optimized for touch and one-handed operation.
